/*
 * InitClocks.h
 *
 *  Created on: 28 juin 2022
 *      Author: jonat
 */

#ifndef INIT_H_
#define INIT_H_

#include "uart.h"

#define TIME_UNTIL_MOVE 4

//Type pour la machine d'�tat
typedef enum{RESET, SETUP, TRACKING, MANUAL_AZ, MANUAL_EL}MODE;
typedef enum{LAT, LONG, YEAR, MONTH, DAY, HOUR, MINUTE, SECOND, DEFAULT}DATA_SETUP;
//Variables globales pour la mesure du capteur Hall
extern int HallSens1, HallSens2;
extern double CurrentDistAZ, CurrentDistEL;
extern int isSleep;

void initTestPorts(void);
MODE ChooseMenu(char sel, int * setup, int * manual_AZ, int * manual_EL, int * tracking);
double strtod(const char *str, char **endptr);
int uint2bcd(unsigned int ival);

#endif /* INIT_H_ */
