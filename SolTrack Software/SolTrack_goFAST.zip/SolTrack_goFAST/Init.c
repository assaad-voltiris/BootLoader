/*
 * InitClocks.c
 *
 *  Created on: 28 juin 2022
 *      Author: jonat
 */
#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "Init.h"
#include "uart.h"

/*==============================================================================
 * // Description : Initialisation des LED en sortie
 * Parametre(s): -
 * Retour      : -
 * ------------------------------------------------------------------------------ */
void initTestPorts(){
    // LEDS as outputs
    P5DIR |= BIT4;
    P5DIR |= BIT3;
    P8DIR |= BIT0;

    //Testpoints as outputs
    P6DIR |= BIT4+BIT5;
    /*
     * P6.4 -> TP8
     * P6.5 -> TP12
     */

    //Eteinds les leds
    P5OUT &= ~BIT4 & ~BIT3;
    P8OUT &=  ~BIT0;
}

int uint2bcd(unsigned int ival){
   return ((ival / 10) << 4) | (ival % 10);
}


MODE ChooseMenu(char sel, int * setup, int * manual_AZ, int * manual_EL, int * tracking){
    static MODE mode;
    if(sel == 's'){
        *setup = 1;
        *manual_AZ = 0;
        *manual_EL = 0;
        *tracking = 0;
        mode = SETUP;
    }
    else if(sel == 'z'){
        *setup = 0;
        *manual_AZ = 1;
        *manual_EL = 0;
        *tracking = 0;
        mode = MANUAL_AZ;
    }
    else if(sel =='e'){
        *setup = 0;
        *manual_AZ = 0;
        *manual_EL = 1;
        *tracking = 0;
        mode = MANUAL_EL;
    }
    else if(sel == 't'){
        *setup = 0;
        *manual_AZ = 0;
        *manual_EL = 0;
        *tracking = 1;
        mode = TRACKING;
    }
    return mode;

}


