
#include <msp430.h>
#include <stdio.h>
#include "Time.h"
#include "Init.h"


//**********************************************************
// R�f�rence :
/*!
 * \file       Rtc.c
 * \brief      MSP430 RTC_A librairy
 * \author     Manolo Vuarrier
 * \version    1
 * \date       30.08.2021
 * \project    Station Meteo
 */
//** PRIVATE
sTimeDate     _localTime;
bool          _RTCflag = 0;
fCallbackVoid _RtcCallBackFunc = NULL;
int isSleep;


#pragma vector=RTC_VECTOR
__interrupt void RTCISR (void)
{

 while(BAKCTL & LOCKBAK)                    // Unlock backup system
        BAKCTL &= ~(LOCKBAK);

  switch(__even_in_range(RTCIV,14))
  {
  case  0: break;                           // Vector  0:  No interrupt
  case  2:                                  // Vector  2:  RTCRDYIFG

      RtcFetchTime();
    break;
  case  4:

      break;                           // Vector  4:  RTCEVIFG
  case  6:
      RTCCTL01 &= ~(RTCAIFG);
      RTCCTL01 &=   ~RTCBCD; //Disable BCD mode
      // Set alarm to the next minute
      RTCAMIN = (RTCMIN+1)%60 | 0x80;
      RTCCTL01 |=   RTCBCD; //enable BCD mode
      if(isSleep){
          __bic_SR_register_on_exit (LPM1_bits); //exit LPM1
          isSleep = 0;
      }


    break;                           // Vector  6:  RTCAIFG
  case  8: break;                           // Vector  8:  RT0PSIFG
  case 10: break;                           // Vector 10:  RT1PSIFG
  case 12: break;                           // Vector 12:  RTCOFIFG
  case 14: break;                           // Vector 14:  Reserved
  default: break;
  }
}


/*!
 * \brief Initialises the RTC (turns the clock ON)
 */
void RtcInit()
{
  RTCCTL01 |=   RTCBCD + RTCHOLD;  // BCD mode, RTC hold

  RTCCTL01 &= ~(RTCTEVIE | RTCAIE | RTCRDYIE | RTCRDYIFG); // Disable interrupt
  RTCAMIN &= 0x00;
  RTCAHOUR &= 0x00;
  RTCADOW &= 0x00;
  RTCADAY &= 0x00;

  RTCCTL01 |= RTCRDYIE;                     // Enable rtc rdy interrupt (1Hz)
  RTCCTL01 &= ~(RTCHOLD);                   // Start RTC calendar mode

  RTCCTL0 |= RTCAIE;                        // Enable alarm interrupts
}

void RtcSetCalibration(int16_t clock_ppm)
{
    if(clock_ppm > 0)
    {
        RTCCTL23 |= RTCCALS;                     // Set positive calibration sign

        clock_ppm = (clock_ppm*125)/512; //RTCCALx = (Absolute Error in ppm) / 4.069, rounded to the nearest integer
                                        // with clock_ppm max : 262 no overflow is possible

    }
    else
    {
        RTCCTL23 &= ~RTCCALS;                     // Set negative calibration sign

        clock_ppm = (-clock_ppm*200)/407; //RTCCALx = (Absolute Error in ppm) / 2.035, rounded to the nearest integer
                                        // with clock_ppm min : -130 no overflow is possible
    }
    RTCCTL23 &= ~0x003F; // Reset RTCCAL (calibration value)
    RTCCTL23 |= 0x003F & clock_ppm; // Set RTCCAL
}

/*!
 * \brief The RTC goes in sleeping mode
 */
void RtcSleep()
{
    RTCCTL01 &=   ~RTCBCD; //Disable BCD mode
    // Set alarm to the next minute
    RTCAMIN = (RTCMIN+1)%60 | 0x80;
    RTCCTL01 |=   RTCBCD; //enable BCD mode

    // Disable RTCrdy interrupt and clr alarm flag
    RTCCTL01 &= ~(RTCRDYIE|RTCAIFG);

    // Enable alarm interrupt
    RTCCTL01 |= RTCAIE;

}

/*!
 * \brief Let the RTC go back in a normal mode
 */
void RtcWakeUp()
{
    // Disable alarm interrupt and clr RTCrdy flag
    RTCCTL01 &= ~(RTCAIE | RTCRDYIFG);

    // Enable rtc rdy interrupt (1Hz)
    RTCCTL01 |= RTCRDYIE;

}


/*!
 * \brief Set callback back function on interruption of Timer A
 */
void RtcSetCallBack(fCallbackVoid func)
{
    _RtcCallBackFunc = func;
}

/*!
 * \brief Execute callback back function on interruption of Timer A
 */
void RtcExecuteCallBack()
{
    _RtcCallBackFunc();
}

/*!
 * \brief Fetch the RTC registers (BCD)
 */
void RtcFetchTime()
{
    // Decode
    _localTime.Seconds   = RTCSEC  & 0x7F;
    _localTime.Minutes   = RTCMIN  & 0x7F;
    _localTime.Hours     = RTCHOUR & 0x3F;
    _localTime.Date      = RTCDAY  & 0x3F;
    _localTime.DayOfWeek = RTCDOW  & 0x07;
    _localTime.Month     = RTCMON  & 0x1F;
    _localTime.Year      = RTCYEAR;
}

/*!
 * \brief Cyclic execution
 */
void    RtcCyclic()
{
    if(_RTCflag)
    {
        RtcFetchTime();
        _RTCflag = false;
    }
}

/*!
 * \param *output Putput time and date
 * \brief Get the time and data
 */
void    RtcGetTime(sTimeDate *output)
{
    uint8_t i;

    for(i=0; i<sizeof(sTimeDate); i++)
    {
        *((uint8_t*)output + i) = *((uint8_t*)&_localTime + i);
    }
}

/*!
 * \return Days in Packed BCD
 * \brief Get the hours
 */
uint8_t   RtcGetDays()
{
    return _localTime.Date;
}

/*!
 * \return Months in Packed BCD
 * \brief Get the hours
 */
uint8_t   RtcGetMonths()
{
    return _localTime.Month;
}

/*!
 * \return Years in Packed BCD
 * \brief Get the hours
 */
uint8_t   RtcGetYears()
{
    return _localTime.Year;
}

/*!
 * \return Hours in Packed BCD
 * \brief Get the hours
 */
uint8_t   RtcGetHours()
{
    return _localTime.Hours;
}

/*!
 * \return Minutes in Packed BCD
 * \brief Get the minutes
 */
uint8_t   RtcGetMinutes()
{
    return _localTime.Minutes;
}

/*!
 * \return Seconds in Packed BCD
 * \brief Get the seconds
 */
uint8_t   RtcGetSeconds()
{
    return _localTime.Seconds;
}

/*!
 * \param *out Output string
 * \brief Get the time string. Ex : 23:54:12
 */
void    RtcGetTimeString(char *out)
{
    //char delimiter = RTC_GET_MFP()?' ':':';
    char delimiter = ':';

    out[0] = (_localTime.Hours >> 4) + '0';
    out[1] = (_localTime.Hours & 0x0F) + '0';
    out[2] = delimiter;
    out[3] = (_localTime.Minutes >> 4) + '0';
    out[4] = (_localTime.Minutes & 0x0F) + '0';
    out[5] = delimiter;
    out[6] = (_localTime.Seconds >> 4) + '0';
    out[7] = (_localTime.Seconds & 0x0F) + '0';
    out[8] = '\0';
}

/*!
 * \param *input Input date and time
 * \brief Set the date and time
 */
void    RtcSetTime(sTimeDate *input)
{
    RTCSEC  = 0x00;                             // Seconds to 0, start clock
    RTCMIN  = input->Minutes & 0x7F;            // Minutes
    RTCHOUR = input->Hours & 0x3F;              // Hours (24H)
    RTCDAY  = input->Date & 0x3F;               // Day
    RTCDOW  = input->DayOfWeek & 0x07;          // Day of Week
    RTCMON  = input->Month & 0x1F;              // Month
    RTCYEAR = input->Year;                      // Year
}


void RtcGetTimeToDecimal(sTimeDate *input)
{
    input->Seconds   = (input->Seconds   >> 4) * 10 + (input->Seconds   & 0x0F);
    input->Minutes   = (input->Minutes   >> 4) * 10 + (input->Minutes   & 0x0F);
    input->Hours     = (input->Hours     >> 4) * 10 + (input->Hours     & 0x0F);
    input->DayOfWeek = (input->DayOfWeek >> 4) * 10 + (input->DayOfWeek & 0x0F);
    input->Date      = (input->Date      >> 4) * 10 + (input->Date      & 0x0F);
    input->Month     = (input->Month     >> 4) * 10 + (input->Month     & 0x0F);
    input->Year      = (input->Year      >> 4) * 10 + (input->Year      & 0x0F);
}



void InitOscillator()
{
    while(BAKCTL & LOCKBAK)                    // Unlock XT1 pins for operation
        BAKCTL &= ~(LOCKBAK);

    UCSCTL6 &= ~(XT1OFF);                     // XT1 On
    UCSCTL6 |= XCAP_1;                        // Internal load cap

    P7SEL |= BIT2+BIT3;                       // Port select XT2
    UCSCTL6 &= ~XT2DRIVE_0;                     // XT2 oscillator operating range is 4 MHz to 8 MHz
    UCSCTL6 &= ~XT2OFF;                       // Set XT2 On
    // Loop until XT1,XT2 & DCO stabilizes - In this case loop until XT1 and DCo settle
    do
    {
        UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                                // Clear XT2,XT1,DCO fault flags
        SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag

    UCSCTL3 |= SELREF__XT2CLK | FLLREFDIV__2; // Set DCO FLL reference /2 = XT2/2 (4MHz)
    UCSCTL4 = SELA__XT1CLK | SELM__DCOCLK | SELS__DCOCLK;// Set ACLK = XT1(32kHz), SMCLK = DCO, MCLK = DCO
    UCSCTL5 |= DIVM__2 | DIVS__1 | DIVA__1;  // MCLK = fSELM/2 = 10MHz  SMCLK = fSELS/1 = 20MHz
    __bis_SR_register(SCG0);                  // Disable the FLL control loop

    //UCSCTL0 = 0x0F80;                       // Select DCO range 2.5-54.1MHz operation
    UCSCTL1 = DCORSEL_5;                      // DCOx = auto MODx = auto, DCORSELx = 5 see datasheet page 31

    UCSCTL2 = FLLD__1 + FLLN2;              // Set Multiplier for 40MHz
                                            // D *(N + 1) * FLLRef = Fdco
                                            // 1 * (4 + 1) * 4MHz = 20MHz
                                            // FLL Div = fDCOCLK/1
    __bic_SR_register(SCG0);                  // Enable the FLL control loop

    // Worst-case settling time for the DCO when the DCO range bits have been
    // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 6xx
    // UG for optimization.
    // 32 x 32 x 10 MHz / 8MHz = 1280 = MCLK cycles for DCO to settle
    __delay_cycles(1280);

    // Loop until XT1,XT2 & DCO fault flag is cleared
    do
    {
        UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                                // Clear XT2,XT1,DCO fault flags
        SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    }while (UCSCTL7&OFIFG);                   // Test oscillator fault flag

}
/*
 * Pour une raison que j'ignore, il semble que la fr�quence de MCLK doit �tre plus basse que
 * la fr�quence de SMClK. Autrement, le syst�me crash par moment
 */


/*==============================================================================
 * // Description : Initialisation du timer TA1 pour compter les ms
 * Parametre(s):
 * Retour      :
 * ------------------------------------------------------------------------------ */
void initTimerA1(){
    WDTCTL = WDTPW + WDTHOLD; //arr�t du watchdog

    //Init Timer A1
     TA1CCTL0 |= CCIE;
     TA1CCR0 = F_SMCLK/1000 - 1; //Fait compter TA1CCR0 jusqu'� 20'000, correspondant � 1ms
     TA1CTL |= TASSEL__SMCLK + MC_1 + TACLR; //source SMCLK, compte jusqu'� TA1CCR0, clear
}
