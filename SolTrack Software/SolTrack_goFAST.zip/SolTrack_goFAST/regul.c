/*
 * regul.c
 *
 *  Created on: 6 juil. 2022
 *      Author: jonat
 */

#include <msp430.h>
#include "Time.h"
#include "regul.h"
#include "Init.h"
#include "EoT.h"
#include "ADC.h"




/*==============================================================================
 * Description : D�place le moteur d'azimuth, moteur 1
 *              //                MSP430F66xx
 *            -----------------
 *        /|\|             P2.0|--|
 *         | |                 | MOT1, AZ
 *         --|RST          P2.1|--|
 *           |                 |
 *           |             P6.0|<-- HallSens1
 *                         P6.6|-->Vref MOT1
 *
 * Parametre(s): double deltaAZ, distance en mm
 * Retour      : int flag, indique si le mouvement est termin�
 * ------------------------------------------------------------------------------ */
void mvtMotorAZ(double deltaAZ){
    int D = 0;
    D = calcDutyCycle(deltaAZ);
    MotorAZmove(D);
}

/*==============================================================================
 * Description : D�place le moteur d'azimuth, moteur 1
 *              //                MSP430F66xx
 *            -----------------
 *        /|\|             P1.5|--|
 *         | |                 | MOT2, EL
 *         --|RST          P1.6|--|
 *           |                 |
 *           |             P6.1|<-- HallSens2
 *                         P6.7|--> Vref MOT2
 *
 * Parametre(s): double deltaEL en mm
 * Retour      :
 * ------------------------------------------------------------------------------ */
void mvtMotorEL(double deltaEL){
    int D = 0;
    D = calcDutyCycle(deltaEL);
    MotorELmove(D);
}
/*==============================================================================
 * // Description : Calcul le courant � envoyer au moteur pour permettre le d�placement
 *                  voulu. Le profil choisi est un profil dit "bangbang"
 * Parametre(s): int ms le temps en ms, double deltaX distance du d�placement,
 *               double deltaT temps de d�placement en ms
 * Retour      : double Ic le courant de consigne
 * ------------------------------------------------------------------------------ */
int calcDutyCycle(double deltaX){

    static unsigned int D, t; //Rapport cyclique
    double Vmax, Umot, Vmot, p;
    //static double p_stock;
    Vmax = deltaX*T2_S_INV;  //Trap�ze ramen� en un rectangle

    Umot = (2*D-1)*UIN;
    Vmot = Umot * KU;
    if(deltaX > 0){
        D = 80;
    }
    else if (deltaX< 0){
        D = 20;
    }
    else if (deltaX == 0){
        D = 50;
    }
    return D;

    /*//calcul de l'acc�leration en fonction du temps
    if(ms <= T1_MS){
        if(horloge1ms){
            t++;
            //p = 0.5*am*t^2; //Calcul de la position
            p_stock = p;
            if(Vmot < Vmax){
                D++;
                horloge1ms = 0;
            }
        }

    }
    else if(ms > T1_MS && ms <= T2_MS){
        if(horloge1ms){
            t++;
            p = Vmax*(t-T1_S)+p_stock;
        }


    }
    else{
        if(horloge1ms){
            if(Vmot > 0){
                D--;
                horloge1ms = 0;
            }
        }
    }

    /*
     * A la fin de chaque partie du profil ajouter une correction par rapport � la distance atteinte ou non et
     *
     */

    //conversion de l'acc�leration en courant de consigne



}


/*==============================================================================
 * // Description : Mesure la distance parcourue par le moteur 1 d'azimuth
 * Parametre(s): Variable globale, HallSens1
 * Retour      : int c la distance parcourue en mm
 * ------------------------------------------------------------------------------ */
int mesDistMotorAZ(double deltaAZ, int AZFlag){
    /*
     * 5V du capteur Hall vaut 3.1V sur l'entr�e de l'uC
     * Soit -> 3930 -> 0xF5A. Trigger de Schmidt software
     * pour voir si on d�passe bien cette valeur
     */
    static int OldValue, dir, step;

    HallSens1 = ADC12MEM0;

    if(deltaAZ > 0){
        dir = FWD;
    }
    else if(deltaAZ < 0){
        dir = BWD;
    }
    else{
        dir = dir;
    }

    if(HallSens1 >= UPPER_TRIGG && OldValue == LOW){
        if(dir == FWD){
            step++;
            CurrentDistAZ += 0.1;
        }
        else if (dir == BWD){
            step++;
            CurrentDistAZ -= 0.1;
        }
        OldValue = HIGH;
    }
    else if(HallSens1 <= LOWER_TRIGG && OldValue == HIGH){
        OldValue = LOW;
    }

    if(step >= abs(deltaAZ)*10){
        step = 0;
        AZFlag = 0;
    }
    return AZFlag;
}

/*==============================================================================
 * // Description : Mesure la distance parcourue par le moteur d'EL
 * Parametre(s): Variable globale, HallSens1
 * Retour      : int c la distance parcourue en mm
 * ------------------------------------------------------------------------------ */
int mesDistMotorEL(double deltaEL, int ELFlag){
    /*
     * 5V du capteur Hall vaut 3.1V sur l'entr�e de l'uC
     * Soit -> 3930 -> 0xF5A. Trigger de Schmidt software
     * pour voir si on d�passe bien cette valeur
     */
    static int OldValue, dir, step;

        HallSens2 = ADC12MEM1;

        if(deltaEL > 0){
            dir = FWD;
        }
        else if(deltaEL < 0){
            dir = BWD;
        }
        else{
            dir = dir;
        }

        if(HallSens2 >= UPPER_TRIGG && OldValue == LOW){
            if(dir == FWD){
                step++;
                CurrentDistEL += 0.1;
            }
            else if (dir == BWD){
                step++;
                CurrentDistEL -= 0.1;
            }
            OldValue = HIGH;
        }
        else if(HallSens2 <= LOWER_TRIGG && OldValue == HIGH){
            OldValue = LOW;
        }

        if(step >= abs(deltaEL)*10){
            step = 0;
            ELFlag = 0;
        }
        return ELFlag;
}


/*==============================================================================
 * Description : fait avancer le moteur 1, azimuth
 * Parametre(s):int DC, rapport cyclique pour le moteur entre 0 et 100.
 *               Les deux timers
 *               re�oivent le m�me rapport cyclique car ils travaillent en
 *               inverse.
 * Retour      :
 * ------------------------------------------------------------------------------ */
void MotorAZmove(int D){
    //forward
    if(D>50){
        P2OUT |= BIT0;
        P2OUT &= ~BIT1;
    }
    //backward
    else{
        P2OUT &= ~BIT0;
        P2OUT |= BIT1;
    }
}

/*==============================================================================
 * Description : Arr�te le moteur 1, azimuth
 * Parametre(s):
 * Retour      :
 * ------------------------------------------------------------------------------ */
void MotorAZstop(){
    P2OUT &= ~BIT0;
    P2OUT &= ~BIT1;
}

/*==============================================================================
 * Description : fait avancer le moteur 2, elevation
 * Parametre(s): int DC, rapport cyclique pour le moteurentre 0 et 100.
 *               Les deux timers
 *               re�oivent le m�me rapport cyclique car ils travaillent en
 *               inverse.
 * Retour      :
 * ------------------------------------------------------------------------------ */
void MotorELmove(int D){
    //forward
    if(D>50){
        P1OUT |= BIT6;
        P1OUT &= ~BIT7;
    }
    //backward
    else{
        P1OUT &= ~BIT6;
        P1OUT |= BIT7;
    }
}

/*==============================================================================
 * Description : Arr�te le moteur 2, elevation
 * Parametre(s):
 * Retour      :
 * ------------------------------------------------------------------------------ */
void MotorELstop(){
    P1OUT &= ~BIT6;
    P1OUT &= ~BIT7;
}
/*==============================================================================
 * Description : Remet les deux moteurs en position initiale
 * Parametre(s):
 * Retour      :
 * ------------------------------------------------------------------------------ */
void GoToSleep(){
    //static int EL_flag, AZ_flag;
    if(abs(CurrentDistAZ) > POS_ZERO){
            if(CurrentDistAZ < POS_ZERO){
                mvtMotorAZ(-RET_START);
            }
            else{
                mvtMotorAZ(RET_START);
            }
        }
        else{
            MotorAZstop();
        }

        if(abs(CurrentDistEL) > 0){
            if(CurrentDistEL < 0){
                mvtMotorEL(-RET_START);
            }
            else{
                mvtMotorEL(RET_START);
            }
        }
        else{
           MotorELstop();
        }

  //  if(EL_flag == 0 && AZ_flag == 0){
  //      __bis_SR_register(LPM1_bits + GIE); // Enter LPM1
  //  }
}

/*==============================================================================
 * Description : D�place le moteur d'azimuth, moteur 1
 *              //                MSP430F66xx
 *            -----------------
 *        /|\|       TA0.1/P1.6|--> MOT2 IN1
 *         | |                 |
 *         --|RST    TA0.2/P1.7|--> MOT2 IN2
 *           |                 |
 *           |       TB0.1/P2.0|--> MOT1 IN1
 *                             |
 *                   TB0.6/P2.1|--> MOT1 IN2
 *
 *               Ports mapping
 *   P1.6 -> Hridve2 in1 -> TP25 -> TA0.1
 *   P1.7 -> Hdrive2 in2 -> TP23 -> TA0.2
 *   P2.0 -> Hdrive1 in1 -> TP25 -> TB0.1
 *   P2.1 -> Hdrive1 in2 -> TP23 -> TB0.6
 *
 *   Sur moteur : Fil blanc avec fil bleu
 *                Fil vert avec fil brun
 *
 * Parametre(s):
 * Retour      :
 * ------------------------------------------------------------------------------ */
void initPWM(){
    /* Les sorties pour le Hdrive 1 on �t� mal c�bl�es. Il aurait fallu les mettre
     * sur une sortie timer. Pour �viter de devoir faire un c�blage moche sur le PCB,
     * je fais du port mapping via le port2 et le timerB
     * Le mieux est de changer �a de mani�re hardware pour la prochaine version du
     * PCB
     */
    // Enable Write-access to modify port mapping registers
     PMAPPWD = 0x02D52;
     P2MAP0 = PM_TB0CCR1B; //Map TB0CCR1 to P2.0
     P2MAP1 = PM_TB0CCR6B; //Map TB0CCR6 to P2.1

     P2DIR |= BIT0+BIT1;   //P2.0 and P2.1 output
     P2SEL |= BIT0+BIT1;   //P2.0 and P2.1 option select

     PMAPPWD = 0; // Disable Write-Access to modify port mapping registers


    //SMCLK = 20MHz
    //PWM freq = 40KHz -> PWM Period = 25us -> int = 25us*20MHz = 500
    //Setup Timer TA0
    P1DIR |= BIT6+BIT7;                       // P1.6 and P1.7 output
    P1SEL |= BIT6+BIT7;                       // P1.6 and P1.7 options select
    TA0CCR0 = PWM_PERIOD;                     // PWM Period -> 25us
    TA0CCTL1 = OUTMOD_7;                      // CCR1 reset/set
    TA0CCTL2 = OUTMOD_3;                      // CCR2 set/reset -> inverse pwm
    TA0CTL = TASSEL_2 + MC_1 + TACLR;         // SMCLK, up mode, clear TAR


    TB0CCR0 = PWM_PERIOD;                     // PWM Period -> 25us
    TB0CCTL1 = OUTMOD_7;                      // CCR1 reset/set
    TB0CCTL6 = OUTMOD_3;                      // CCR2 set/reset -> inverse pwm
    TB0CTL = TASSEL_2 + MC_1 + TACLR;         // SMCLK, up mode, clear TAR

    /*Ports mapping
     * P1.6 -> Hridve2 in1 -> TP25 -> TA0.1
     * P1.7 -> Hdrive2 in2 -> TP23 -> TA0.2
     * P2.0 -> Hdrive1 in1 -> TP25 -> TB0.1
     * P2.1 -> Hdrive1 in2 -> TP23 -> TB0.2
     */
}
