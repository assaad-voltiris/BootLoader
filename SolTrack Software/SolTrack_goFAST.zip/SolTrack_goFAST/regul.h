/*
 * regul.h
 *
 *  Created on: 6 juil. 2022
 *      Author: jonat
 */

#ifndef REGUL_H_
#define REGUL_H_

#define KT          0.069       //constante de couple [Nm/A]
#define KF          0.0023      //rapport entre la force et le courant
#define P           0.00010909  //rapport en vitesse angulaire et lin�aire
#define DEUXPI      6.2832
#define M_REFLECT   3           // Poid que dois pousser un moteur
                                // Un r�flecteur fait 9kg. 3kg est une grosse approximation

/*
 * Le profil de mouvement et le temps de mouvement n'est pas d�fini par le cahier des charges
 * -> Trap�ze 1/3, 1/3, 1/3
 * -> TMOV = 3s
 * -> X    = ?
 */

#define VMAX        5
#define INV_VMAX    0.2
#define TMOV_MS     300
#define T1_MS       100
#define T2_MS       200
#define T3_MS       300
#define T1_S        1
#define T2_S        2
#define T2_S_INV    0.5
#define T3_S        3
#define CM_TO_STEP  100
#define MM_TO_STEP  10
#define TOTAL_STEP  4000
#define RET_START   -400
#define POS_ZERO    0.0


#define UPPER_TRIGG 3200
#define LOWER_TRIGG 200
#define LOW         0
#define HIGH        1
#define FWD         1
#define BWD         0


#define AZ_GAIN         1.41   //mm/� -> 1.22 avant
#define EL_GAIN         2.94   //mm/� -> 2.74 avant
#define EL_AZ_COUPLING  0.35 //�/mm -> 0.28571 avant


#define PWM_PERIOD      (500-1)     //PWM Period = int/SMCLK = 500/20e6 = 25us
#define PWM_DC          50         //50% PWM
#define UIN             24         //Tension moteur de 24V
#define KU              0.069


int calcVref(double Ic);
int calcDutyCycle(double deltaX);
int mesDistMotorAZ(double deltaAZ, int AZFlag);
int mesDistMotorEL(double deltaEL, int ELFlag);
void mvtMotorAZ(double deltaAZ);
void mvtMotorEL(double deltaEL);

void MotorAZmove(int DC);
void MotorELmove(int DC);
void MotorAZstop(void);
void MotorELstop(void);
void GoToSleep(void);

void initPWM();

extern double AZ_gain, EL_gain, Mec_coupling;


#endif /* REGUL_H_ */
