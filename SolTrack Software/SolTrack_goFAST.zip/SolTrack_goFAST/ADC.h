/*
 * ADC.h
 *
 *  Created on: 5 juil. 2022
 *      Author: jonat
 */

#ifndef ADC_H_
#define ADC_H_

void initADC(void);
void initDAC(void);
void ADCOff();
void ADCOn();

#endif /* ADC_H_ */
