#ifndef EOT_H_
#define EOT_H_

#define TO_RAD 0.0175
#define TO_DEG 57.2958

#define DIF_ANGLE_EL    0.2450     //rad difference btw reflector angle and sun angle


double convert_dms_dd(double deg, double min, double sec);
double calcAZ(double EL_RAD, double HRA_RAD, double declination_RAD, double lat);
double calcEL(double lat, double declination, double HRA);
double calcDistAZ(double AZ_RAD);
double calcDistEL(double EL_RAD, double AZ_RAD);
double calcEoT(int Day_N);
double calcDeclination(int Day_N);
double calcHRA(double EoT, double Long, double LT, int DeltaTutc);

#endif
