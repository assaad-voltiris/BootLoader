/*
 * EoT_.c
 *
 *  Created on: 27 juin 2022
 *      Author: jonat
 */


#include "EoT.h"
#include "regul.h"
#include <math.h> //Return values are in radians

/*==============================================================================
 * // Description : Calcul de l'�quation of time, permet l'asjutement entre
 * l'heure local et l'heure solaire
 * Parametre(s): Double N, num�ro du jour actuel
 * Retour      : double E, la diff�rence entre l'heure locale et l'heure solaire
 * ------------------------------------------------------------------------------ */

double calcEoT(int Day_N){
    volatile double B, EoT,a ,b ,c ,d;
    //The constants are given by https://susdesign.com/popups/sunangle/eot.php
    //N is the day number
    B = 2*M_PI*(Day_N-81)*0.0027397260273973; //B in radians, 81 as March 22nd *0.0027 = /365
    d = 2*B;
    a = 9.87*sin(d);
    b = 7.53*cos(B);
    c = 1.5*sin(B);
    EoT = a - b - c;
    //EoT = 9.87*sin(2*B) - 7.53*cos(B) - 1.5*sin(B);
    return EoT; //Return EoT in minutes
}

/*==============================================================================
 * // Description : Calcul l'angle entre la terre et le soleil
 * Parametre(s): N, le jour actuel
 * Retour      : declination, l'angle en radian
 * ------------------------------------------------------------------------------ */
double calcDeclination(int Day_N){
    double declination_RAD;
    declination_RAD = 23.45*sin(0.0172*(Day_N+284))*TO_RAD;//284 as October the 11th
    return declination_RAD;

}

/*==============================================================================
 * // Description :
 * Parametre(s):
 * Retour      :
 * ------------------------------------------------------------------------------ */
double convert_dms_dd(double deg, double min, double sec){
    double result;
    result = deg + min / 60 + sec / 3600;
    return result;
}

/*==============================================================================
 * // Description : Calculate the hour angle for a given time. You first need to
 *                  convert the local time (LT) to the local solar time (LST).
 * Parametre(s) : EoT, equation of time; Long, longitude en �; LT, local time en minutes;
 *                DeltaTutc, the time difference from Greenwich
 * Retour      :  HRA, Hour Angle
 * ------------------------------------------------------------------------------ */
double calcHRA(double EoT, double Long, double LT, int DeltaTutc){
    double LSTM, TC, LST, HRA,HRA_RAD;
    LSTM = 15*DeltaTutc;
    TC = 4*(Long - LSTM)+EoT;
    LST = LT+TC/60;
    HRA = 15*(LST-12); //in degrees
    HRA_RAD = HRA*TO_RAD; //in radians
    return HRA_RAD;
}


/*==============================================================================
 * // Description : Calcul de l'aziumth solaire
 * Parametre(s) :double EL_RAD, l'�levation du soleil; double HRA_RAD, hour angle;
 * double declination_RAD, angle entre le terre et le soleil; double lat, lattitude actuelle
 * Retour      :
 * ------------------------------------------------------------------------------ */
double calcAZ(double EL_RAD, double HRA_RAD, double declination_RAD, double Lat_rad){

    double AZ_RAD;
    AZ_RAD = acos((sin(declination_RAD)*cos(Lat_rad) - cos(declination_RAD)*sin(Lat_rad)*cos(HRA_RAD)) / cos(EL_RAD));

    if(HRA_RAD > 0){
        AZ_RAD = 2*M_PI - AZ_RAD;
    }

    return AZ_RAD;

}

/*==============================================================================
 * // Description : Calcul de l'�levation solaire
 * Parametre(s) : double lat, lattitude � la position;
 * double declination, angle entre la terre et le soleil; double HRA, hour angle
 * Retour      : double EL, l'�levation du soleil
 * ------------------------------------------------------------------------------ */
double calcEL(double Lat_rad, double declination_RAD, double HRA_RAD){
    double EL_RAD;
    EL_RAD =  asin(sin(Lat_rad)*sin(declination_RAD)+cos(Lat_rad)*cos(declination_RAD)*cos(HRA_RAD));
    return EL_RAD;

}

/*==============================================================================
 * // Description : Calcul de la distance en cm
 * Parametre(s) : EL_RAD, AZ_RAD
 * Retour      : distEL
 * ------------------------------------------------------------------------------ */
double calcDistEL(double EL_RAD, double AZ_RAD){
    double distEL;
    distEL = EL_RAD*EL_GAIN*TO_DEG - EL_GAIN*AZ_RAD*AZ_GAIN*EL_AZ_COUPLING*TO_DEG; //Distance � bouger

    return distEL;

}
/*==============================================================================
 * // Description : Calcul de la distance en cm
 * Parametre(s) : AZ_RAD
 * Retour      : distAZ
 * ------------------------------------------------------------------------------ */
double calcDistAZ(double AZ_RAD){
    double distAZ;
    distAZ = AZ_RAD*AZ_GAIN*TO_DEG;
    return distAZ;
}
