/*
 * regul.c
 *
 *  Created on: 6 july. 2022
 *      Author: jonat
 *  Last modification on: 23 April 2023.
 *      Author: Yubal Barrios
 */

#include <msp430.h>
#include "Time.h"
#include "regul.h"
#include "Init.h"
#include "ADC.h"

char debugMessage[30] = { '\0' };
char AZString_tmp[9] = { '\0' };

/*==============================================================================
 * // Description : Measure the distance moved by the azimuth motor (motor 1)
 * Parameter(s): double deltaAZ, distance in mm
 *               int AZFlag, which indicates if a movement should be done
 * Return      : int AZFlag, which indicates if the movement is completed or not
 * ------------------------------------------------------------------------------ */
int mesDistMotorAZ(float deltaAZ, int AZFlag)
{
    /*
     * 5V from the Hall sensor is 3.1V on the input of the uC
     * So -> 3930 -> 0xF5A. Schmidt software trigger
     * to see if this value is exceeded
     */
    static int OldValue = LOW, dir, step;

    if (motor_block == 1)
    {
        HallSens1 = P6IN & BIT0;

//Using LED1 to see Hall sensor is working
        if (HallSens1)
        {
            P5OUT |= BIT3;
        }
        else
        {
            P5OUT &= ~BIT3;
        }

        if (deltaAZ > 0)
        {
            dir = FWD;
            mv_dir_AZ = '+';
        }
        else if (deltaAZ < 0)
        {
            dir = BWD;
            mv_dir_AZ = '-';
        }
        else
        {
            dir = dir;
        }

        if (AZFlag)
        {
            if (HallSens1 == HIGH && OldValue == LOW)
            {
                if (dir == FWD)
                {
                    step++;
                    CurrentDistAZ += HallPulse2mm;

                }
                else if (dir == BWD)
                {
                    step++;
                    CurrentDistAZ -= HallPulse2mm;

                }
                OldValue = HIGH;

            }

            else if (HallSens1 == LOW && OldValue == HIGH)
            {
                OldValue = LOW;
            }

            DistAZ = deltaAZ-CurrentDistAZ;

        }
        if (step >= fabs(deltaAZ) * numberHallPulses)
        {
            absolutePosAZ += CurrentDistAZ;
            step = 0;
            AZFlag = 0;
            CurrentDistAZ = 0;

        }
    }
    else
    {
        AZFlag = 0;
    }



    return AZFlag;
}

/*==============================================================================
 * // Description : Measure the distance moved by the elevation motor (motor 2)
 * Parameter(s): double deltaEL, distance in mm
 *               int ELFlag, which indicates if a movement should be done
 * Return      : int ELFlag, which indicates if the movement is completed or not
 * ------------------------------------------------------------------------------ */
int mesDistMotorEL(float deltaEL, int ELFlag)
{
    /*
     * 5V from the Hall sensor is 3.1V on the input of the uC
     * So -> 3930 -> 0xF5A. Schmidt software trigger
     * to see if this value is exceeded
     */
    static int OldValue = LOW, dir, step;

    if (motor_block == 1)
    {
        HallSens2 = P6IN & BIT1;

        //Using LED2 to see Hall sensor is working
        if (HallSens2)
        {
            P5OUT |= BIT4;
        }
        else
        {
            P5OUT &= ~BIT4;
        }

        // Hall Sensor 2 depends on BIT1, so it is "HIGH" when 0x02
        if (HallSens2 != LOW)
            HallSens2 = HIGH;

        if (deltaEL > 0)
        {
            dir = FWD;
            mv_dir_EL = '+';

        }
        else if (deltaEL < 0)
        {
            dir = BWD;
            mv_dir_EL = '-';

        }
        else
        {
            dir = dir;
        }
        if (ELFlag)
        {
            if (HallSens2 == HIGH && OldValue == LOW)
            {
                if (dir == FWD)
                {
                    step++;
                    CurrentDistEL += HallPulse2mm;
                }
                else if (dir == BWD)
                {
                    step++;
                    CurrentDistEL -= HallPulse2mm;
                }
                OldValue = HIGH;
            }

            else if (HallSens2 == LOW && OldValue == HIGH)
            {
                OldValue = LOW;
            }

            DistEL = deltaEL - CurrentDistEL;
        }
        if (step >= fabs(deltaEL) * numberHallPulses)
        {
            absolutePosEL += CurrentDistEL;
            step = 0;
            ELFlag = 0;
            CurrentDistEL = 0;
        }
    }
    else
    {
        ELFlag = 0;
    }
    return ELFlag;
}

/*==============================================================================
 * Description : Displacement of azimuth motor (motor 1)
 *              //                MSP430F66xx
 *            -----------------
 *        /|\|             P1.6|--|
 *         | |                 | MOT1, AZ
 *         --|RST          P1.7|--|
 *           |                 |
 *           |             P6.0|<-- HallSens1
 *                         P6.6|-->Vref MOT1
 *
 * Parameter(s): double deltaAZ, distance in mm
 * Return      :
 * ------------------------------------------------------------------------------ */
void MotorAZmove(float deltaAZ)
{

    int D;
    int absDistAZ = abs(DistAZ);
    if (motor_block == 1)
    {
        if (initial_counterAZ < START_COUNTER)
        {
            D = LOW_SPEED;
            initial_counterAZ += 0.005;
        }

        else if (absDistAZ >= 20)
        {

            D = HIGH_SPEED;

        }
        else if (absDistAZ >= 8)
        {
            D = MEDIUM_SPEED;
        }
        else
        {
            D = STOP_SPEED;
        }

        if (deltaAZ < 0)
        {

            TA0CCR2 = D;
            TA0CCR1 = 0;
        }
        else if (deltaAZ > 0)
        {
            TA0CCR2 = 0;
            TA0CCR1 = D;
        }
        else
        {
            TA0CCR2 = 0;
            TA0CCR1 = 0;
        }
    }

}

/*==============================================================================
 * Description :stops azimuth motor (motor 1)
 * Parameter(s):
 * Return      :
 * ------------------------------------------------------------------------------ */
void MotorAZstop()
{
    if (motor_block == 1)
    {
        TA0CCR2 = 0;
        TA0CCR1 = 0;
    }
}

/*==============================================================================
 * Description : Displacement of elevation motor (motor 2)
 *              //                MSP430F66xx
 *            -----------------
 *        /|\|             P1.4|--|
 *         | |                 | MOT2, EL
 *         --|RST          P1.5|--|
 *           |                 |
 *           |             P6.1|<-- HallSens2
 *                         P6.7|--> Vref MOT2
 *
 * Parameter(s): double deltaEL in mm
 * Return      :
 * ------------------------------------------------------------------------------ */
void MotorELmove(float deltaEL)
{

    int D;

    int absDistEL = abs(DistEL);

    if (motor_block == 1)
    {
        if (initial_counterEL < START_COUNTER)
        {
            D = LOW_SPEED;
            initial_counterEL += 0.005;
        }

        else if (absDistEL >= 20)
        {
            D = HIGH_SPEED;
        }
        else if (absDistEL >= 8)
        {
            D = MEDIUM_SPEED;
        }
        else
        {
            D = STOP_SPEED;
        }

        if (deltaEL < 0)
        {

            TA0CCR4 = D;
            TA0CCR3 = 0;
        }
        else if (deltaEL > 0)
        {
            TA0CCR4 = 0;
            TA0CCR3 = D;
        }
        else
        {
            TA0CCR4 = 0;
            TA0CCR3 = 0;
        }
    }
}

/*==============================================================================
 * Description :stops elevation motor (motor 2)
 * Parameter(s):
 * Return      :
 * ------------------------------------------------------------------------------ */
void MotorELstop()
{
    if (motor_block == 1)
    {
        TA0CCR4 = 0;
        TA0CCR3 = 0;
    }
}

/*==============================================================================
 * Description : PWM configuration and initialization
 * Parameter(s):
 * Return      :
 * ------------------------------------------------------------------------------ */

void initPWM()
{

    P1DIR |= BIT6 + BIT7; //Motor 1 pins has outputs
    P1DIR |= BIT4 + BIT5; //Motor 2 pins has outputs
    P1SEL |= BIT4 + BIT5 + BIT6 + BIT7;

//SMCLK = 20MHz
//PWM freq = 40KHz -> PWM Period = 25us -> int = 25us*20MHz = 500
//Setup Timer TA0

    TA0CCR0 = PWM_PERIOD;              // PWM Period -> 25us
    TA0CCTL1 = OUTMOD_7;                   // CCR1 reset/set
    TA0CCTL2 = OUTMOD_7;                  // CCR2  reset/set
    TA0CCTL3 = OUTMOD_7;                   // CCR3 reset/set
    TA0CCTL4 = OUTMOD_7;                  // CCR4  reset/set
    TA0CTL = TASSEL_2 + MC_1 + TACLR; // SMCLK, up mode, clear TAR

}

/*==============================================================================
 * Description : Comparator_B configuration and initialization
 * Parameter(s):
 * Return      :
 * ------------------------------------------------------------------------------ */

void initComparator()
{

    param.positiveTerminalInput = COMP_B_INPUT2; //Enable V+, input channel CB2 (default option: motor 1 current is measured)
    param.negativeTerminalInput = COMP_B_VREF; // VREF is applied to -terminal
    param.powerModeSelect = COMP_B_POWERMODE_ULTRALOWPOWER;  // normal mode
    param.outputFilterEnableAndDelayLevel = COMP_B_FILTEROUTPUT_DLYLVL1;
    param.invertedOutputPolarity = COMP_B_NORMALOUTPUTPOLARITY;
    Comp_B_init(COMP_B_BASE, &param);

    //Configuration for the low threshold (edge detection)
    //Shared reference (1.5V)* 2/32 = 0.09375 V
    refVoltageParam_Low.supplyVoltageReferenceBase = COMP_B_VREFBASE1_5V;
    refVoltageParam_Low.lowerLimitSupplyVoltageFractionOf32 = 2;
    refVoltageParam_Low.upperLimitSupplyVoltageFractionOf32 = 2;
    refVoltageParam_Low.referenceAccuracy = COMP_B_ACCURACY_STATIC;
    //----------------------------------------------------

    //Configuration for the high threshold (possible collision)
    //Shared reference (2.5V)* 30/32 = 2,34375 V
    refVoltageParam_High.supplyVoltageReferenceBase = COMP_B_VREFBASE2_5V;
    refVoltageParam_High.lowerLimitSupplyVoltageFractionOf32 = 30; //22 is the minimum coefficient to avoid normal movement detection
    refVoltageParam_High.upperLimitSupplyVoltageFractionOf32 = 30; //22 is the minimum coefficient to avoid normal movement detection
    refVoltageParam_High.referenceAccuracy = COMP_B_ACCURACY_STATIC;
    //----------------------------------------------------

    Comp_B_configureReferenceVoltage(COMP_B_BASE, &refVoltageParam_Low);
    __delay_cycles(1500);

    CBCTL1 |= CBON;
}
