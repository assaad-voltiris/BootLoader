/*
 * ADC.c
 *
 *  Created on: 5 juil. 2022
 *      Author: jonat
 */

#include <msp430.h>
#include "ADC.h"

/*==============================================================================
 * // Description : Initialisation de l'ADC, clock source is at MODCLOK at 5MHz
 * Parametre(s): -
 * Retour      : -
 * ------------------------------------------------------------------------------ */
void initADC(){

    ADC12CTL0 = ADC12ON+ADC12MSC+ADC12SHT0_8; // Turn on ADC12, extend sampling time
                                              // to avoid overflow of results
    ADC12CTL1 = ADC12SHP+ADC12CONSEQ_3;       // Use sampling timer, repeated sequence
    //ADC12MCTL0 = ADC12INCH_0;                 // ref+=AVcc, channel = A0
    //ADC12MCTL1 = ADC12INCH_1;                 // ref+=AVcc, channel = A1
    //ADC12MCTL2 = ADC12INCH_2;                 // ref+=AVcc, channel = A2
    //ADC12MCTL3 = ADC12INCH_3;                 // ref+=AVcc, channel = A3
    //ADC12IE = 0x08;                         // Enable ADC12IFG.3
    ADC12CTL0 |= ADC12ENC;                    // Enable conversions

    //P6SEL |= BIT2 | BIT3;                     // P6.2/6.3 ADC option select

    /*Ports mapping
     * P6.2 -> HallSensorFilt.M1 -> TP7
     * P6.3 -> HallSensorFilt.M2 -> TP15
     */

    //Values are stored in ADCMEMx registers
}
/*==============================================================================
 * // Description : Arr�te le sampling de l'ADC
 * Parametre(s): -
 * Retour      : -
 * ------------------------------------------------------------------------------ */
void ADCOff(){
    //ADC12IE = 0;                // Disable ADC12IFG
    ADC12CTL0 &= ~ADC12ENC;     // Disable conversions
    ADC12CTL0 &= ~ADC12SC;      //Stop sampling/conversion
}

/*==============================================================================
 * // Description : D�marre le sampling de l'ADC
 * Parametre(s): -
 * Retour      : -
 * ------------------------------------------------------------------------------ */
void ADCOn(){
    //ADC12IE = 0x08;         // Enable ADC12IFG.3
    ADC12CTL0 |= ADC12ENC;  // Enable conversions
    ADC12CTL0 |= ADC12SC;   //Start sampling/conversion
}

/*==============================================================================
 * // Description : Initialisation du DAC, clock source is at MODCLOK at 5MHz
 * Parametre(s): -
 * Retour      : -
 * ------------------------------------------------------------------------------ */
void initDAC(){

    // AVcc is used as reference, calibration on, DAC on, no amplification
    DAC12_0CTL0 = DAC12IR + DAC12SREF_1 + DAC12AMP_5 + DAC12CALON;
    DAC12_0CTL0 |= DAC12ENC;                  // Enable DAC12 on port 6.2

    //Same as DAC0
    DAC12_1CTL0 = DAC12IR + DAC12SREF_1 + DAC12AMP_5 + DAC12CALON;
    DAC12_1CTL0 |= DAC12ENC;                  // Enable DAC12 on port 6.3

    /*Ports mapping
     * P6.6 -> Hdrive1 Vref -> TP13
     * P6.7 -> Hdrive2 Vref -> TP14
     */

    //To write values
    //DAC12_0DAT = 0xFFF;                       // ~3.3V
    //DAC12_1DAT = 0x0;
}




