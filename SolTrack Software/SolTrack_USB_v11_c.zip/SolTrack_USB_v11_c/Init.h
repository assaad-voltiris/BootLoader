/*
 * InitClocks.h
 *
 *  Created on: 28 juin 2022
 *      Author: jonat
 */

#ifndef INIT_H_
#define INIT_H_

#include "uart.h"

#define TIME_UNTIL_MOVE 4

//Type pour la machine d'�tat
typedef enum{RESET, SETUP, STATUS, MANUAL_AZ, MANUAL_EL, CALIBRATION, MANUAL_BOTH}MODE;
typedef enum{LAT, LONG, YEAR, MONTH, DAY, HOUR, MINUTE, SECOND, DEFAULT}DATA_SETUP;
//Variables globales pour la mesure du capteur Hall
extern char HallSens1, HallSens2;
extern float CurrentDistAZ, CurrentDistEL;
extern int isSleep;

void initPorts();
MODE ChooseMenu(char sel, int * setup, int * manual_AZ, int * manual_EL, int * manual_both, int * tracking, int * calibration);
float strtof(const char *str, char **endptr);
int uint2bcd(unsigned int ival);

#endif /* INIT_H_ */
