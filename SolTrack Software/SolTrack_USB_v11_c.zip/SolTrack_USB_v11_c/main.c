#include <string.h>
#include "driverlib.h"

#include "USB_config/descriptors.h"
#include "USB_API/USB_Common/device.h"
#include "USB_API/USB_Common/usb.h"                 // USB-specific functions
#include "USB_API/USB_CDC_API/UsbCdc.h"
#include "USB_app/usbConstructs.h"

#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Init.h"
#include "Time.h"
#include "regul.h"
#include "ADC.h"
#include "uart.h"
#include "driverlib.h"

#include "hal.h"

#define BUFFER_SIZE 32

// Global flags set by events
volatile uint8_t bCDCDataReceived_event = FALSE; // Indicates data has been rx'ed
// without an open rx operation
volatile uint8_t bDataReceiveCompleted_event = FALSE;

uint8_t usb_counter = 0;

//----- UART Port Configuration parameters and registers (used only for BLE communication)--------------
/*UARTConfig cnf;
 USCIUARTRegs uartUsciRegs;
 USARTUARTRegs uartUsartRegs;

 // Buffers to be used by UART Driver
 unsigned char uartTxBuf[200];
 unsigned char uartRxBuf[200];*/

//---------------------------------------
sTimeDate Time;

char HallSens1, HallSens2;

int time1ms;
int time10ms;
int time100ms = 0, time100ms2 = 0, time1s = 0, time1min = 0, time1h = 7;
int ms;
int min_counter = 0;
int sec_counter = 0;

int drapeau = 0;

float CurrentDistEL = 0, CurrentDistAZ = 0;
float DistAZ = 0, DistEL = 0;
float MaxPosAZ = 410.0, MinPosEL = -10.0;
char mv_dir_AZ, mv_dir_EL;

int numberHallPulses = 10;
float HallPulse2mm = 0.1;
float initial_counterAZ = 0, initial_counterEL = 0;
volatile float deltaEL = 0, distEL, oldDistEL;
volatile float deltaAZ = 0, distAZ, oldDistAZ;
float absolutePosAZ = 0, absolutePosEL = 400.0;
unsigned short error_num = 0;
char motor_block = 0;
int isSleep;

bool az_calibrated = false;

int EL_flag = 0;
int AZ_flag = 0;

volatile int time = 1;
volatile unsigned int i;

Comp_B_configureReferenceVoltageParam refVoltageParam_Low = { 0 };
Comp_B_configureReferenceVoltageParam refVoltageParam_High = { 0 };
Comp_B_initParam param = { 0 };

// GLOBAL UNIQUE IDENTIFIER ___________________________________
struct s_TLV_Die_Record * pDIEREC;
uint8_t bDieRecord_bytes;
uint16_t temp;
void readDieRecord(void); //FUNCTION DEFINED BELOW IN CODE
//--------------------------------------------------------------

// DEFINE SIZE OF MEMORY BUFFERS
#define NUMBER_OF_UINT8  9 //size of UINT8 buffer -> max is 9!
#define NUMBER_OF_UINT16 19 //size of UINT8 buffer -> max is 19!
#define NUMBER_OF_UINT32 16 //size of UINT8 buffer -> max is 16!
#define UINT8_FLASH_SC_START   (0x1880)
#define UINT16_FLASH_SC_START   (0x188A) //10 BYTES SPACING WITH UINT8 SEGMENT  (10 UINT8 units)
#define UINT32_FLASH_SC_START   (0x18B2) //40 BYTES SPACING WITH UINT16 SEGMENT (20 UINT16 units) -- max size 77 bytes= 19 UINT32 units

// CREATE STORABLE RAM BUFFERS
uint8_t RAM_BUFFER_UINT8[9];
uint16_t RAM_BUFFER_UINT16[19];
uint32_t RAM_BUFFER_UINT32[16];
uint32_t VRAM_BUFFER_UINT32[2];

void FLASH_write_SegC (void);


/*  
 * ======== main ========
 */
void main(void)
{

   /////////////////////////////// NV MEMORY READ-OUT AND INITILIZATION OF NV VARIABLES
   // READ THE FLASH AND SET THE VALUES IN RAM ACCORDINGLY
   memcpy(&RAM_BUFFER_UINT8[0],(uint8_t *)UINT8_FLASH_SC_START,NUMBER_OF_UINT8); //copy from UINT8 flash buffer into UINT8 RAM buffer
   memcpy(&RAM_BUFFER_UINT16[0],(uint16_t *)UINT16_FLASH_SC_START,NUMBER_OF_UINT16); //copy from UINT16 flash buffer into UINT16 RAM buffer
   memcpy(&RAM_BUFFER_UINT32[0],(uint32_t *)UINT8_FLASH_SC_START,NUMBER_OF_UINT32); //copy from UINT32 flash buffer into UINT32 RAM buffer
   /////////////////////////////// DATA FROM FLASH SAVED INTO RAM

   // if the board ID has never been initialized (value 0xff for cleared flash), then we set it to 0.
   if(RAM_BUFFER_UINT8[0]>9)
   {RAM_BUFFER_UINT8[0]=0x00;}

   // if the position has never been initialized we ignore the position
   if(RAM_BUFFER_UINT16[0]!=0xffff){
       absolutePosAZ=((float)RAM_BUFFER_UINT16[0])/100;
   }
   if(RAM_BUFFER_UINT16[1]!=0xffff){
          absolutePosEL=((float)RAM_BUFFER_UINT16[1])/100;
   }


   readDieRecord(); // Initializes the two first uint32 bits

    WDTCTL = WDTPW + WDTHOLD;

    InitOscillator();
    RtcInit();
    //initADC();

    //------------------------------------------
    volatile int absDistAZ = 0, absDistEL = 0;
    volatile int absCurrentDistAZ, absCurrentDistEL;

    uint8_t unique_id = 0;
    char id_char = 0;
    bool accepted_mode = false;

    int setup, manual_AZ, manual_EL, manual_both, status, calibration;
    char str[10];
    unsigned short CurrIn1 = HIGH, CurrIn2 = HIGH;
    unsigned short CurrIn1_H = LOW, CurrIn2_H = HIGH;
    char az_moved = 0;
    char CornerFlagAZ = 0; // Used to know if the motor is at an edge
    char CornerFlagEL = 0; // Used to know if the motor is at an edge
    bool firstTimeBothMoving = true;
    bool firstTimeMoving = true;
    char reportMessage[30] = { '\0' };
    char *initialString = "ERR";
    char *intermediateString = ",POS";
    char *breakString = "\r\n";
    char debugString[7] = { '\0' };
    char errString[3] = { '\0' };
    char idString[3] = { '\0' };
    char AZString[8] = { '\0' };
    char ELString[8] = { '\0' };
    char trackingMessage[100] = { '\0' };

    volatile float Mux = 0;

    volatile float a, b, c, d, e, f, g;
    MotorAZstop();
    MotorELstop();

    volatile MODE mode = RESET;
    volatile DATA_SETUP setup_switch = DEFAULT;

// USB OUTPUT BUFFER
    char tempBuf[BUFFER_SIZE];
    memset(tempBuf, 0, BUFFER_SIZE); //cleaning the buffer
    char *IntBuf = { 0 };
    //memset(IntBuf, 0, BUFFER_SIZE); //cleaning the buffer
    char *AuxBuf = { 0 };
    //memset(AuxBuf, 0, BUFFER_SIZE); //cleaning the buffer
    char *AZBuf = { 0 };
    char *ELBuf = { 0 };
//-----------------USB settings ---------------------------
    PMM_setVCore(PMM_CORE_LEVEL_2);
    USBHAL_initPorts();           // Config GPIOS for low-power (output low)
    USBHAL_initClocks(8000000); // Config clocks. MCLK=SMCLK=FLL=8MHz; ACLK=REFO=32kHz
    USB_setup(TRUE, TRUE); // Init USB & events; if a host is present, connect
//-----------------------------------------------------------
    initPorts();
    initPWM();
    initTimerA1();
    initComparator();

    __enable_interrupt();  // Enable interrupts globally

    while (1)
    {

        if (time)
        {

            sprintf(str, "%d:%d:%d\r\n", time1h, time1min, time1s);
            USBCDC_sendDataInBackground((uint8_t*) str, strlen(str),
            CDC0_INTFNUM,
                                        0);
            time = 0;
        }

        ////Stop time fetching when in setup mode
        if (mode != SETUP)
        {
            RtcFetchTime();
            RtcGetTime(&Time);
            RtcGetTimeToDecimal(&Time);
        }

        //START OF THE SWITCH ON THE DIFFERENT OPERATING MODES///
        switch (mode)
        {

        case CALIBRATION:
            if (accepted_mode)
            {
                if (calibration)
                {
                    motor_block = 1;
                    calibration = 0;
                    error_num = 0;
                    MotorAZstop();
                    MotorELstop();
                    USBCDC_sendData(
                            (uint8_t*) "Returning motors to the initial position\r\n",
                            strlen("Returning motors to the initial position\r\n"),
                            CDC0_INTFNUM);

                    if (((absolutePosAZ == POS_ZERO) && (CornerFlagAZ == 1)) || ((absolutePosAZ == POS_ZERO) && (firstTimeMoving == true))) //Calibration not needed; azimuth motor is at zero position
                    {
                        //do nothing
                        az_calibrated = true;
                        firstTimeMoving = false;
                    }
                    else
                    {

                        deltaAZ = RET_START;
                        AZ_flag = 1;
                    }
                }
            }
            break;

        case SETUP:
            if (accepted_mode)
            {
                if (setup)
                {
                    setup = 0;
                    USBCDC_sendDataInBackground(
                            (uint8_t*) "Mode Setup: please provide letter + value: A->PCB Identifier B->POR C->Store config to FLASH E->Day F->Hour G->Minute H->Sec I->view memory M-> AbsPosAZ N-> AbsPosEL\r\n",
                            strlen("Mode Setup: please provide letter + value: A->PCB Identifier B->POR C->Store config to FLASH E->Day F->Hour G->Minute H->Sec I->view memory M-> AbsPosAZ N-> AbsPosEL\r\n"),
                            CDC0_INTFNUM,
                            0);
                    MotorAZstop();
                    MotorELstop();
                    drapeau = 0;
                    time1h = 4;
                }
                if (tempBuf[0] == 'A')
                {
                    tempBuf[0] = '0';
                    RAM_BUFFER_UINT8[0] = atoi(tempBuf);

                }
                else if (tempBuf[0] == 'B') //PoR: Power on Reset
                {
                    WDTCTL = 0xDEAD;//RESET
                }
                else if (tempBuf[0] == 'C')
                {
                    FLASH_write_SegC ();// Store the RAM buffers into FLASH segment C.
                }
                else if (tempBuf[0] == 'D')
                {
                    tempBuf[0] = '0';
                    Mux = atof(tempBuf);
                    Time.Month = uint2bcd(atoi(tempBuf));
                }
                else if (tempBuf[0] == 'E')
                {
                    tempBuf[0] = '0';
                    Mux = atof(tempBuf);
                    Time.Date = uint2bcd(atoi(tempBuf));
                }
                else if (tempBuf[0] == 'F')
                {
                    tempBuf[0] = '0';
                    Mux = atof(tempBuf);
                    Time.Hours = uint2bcd(atoi(tempBuf));
                    time1h = Time.Hours;
                }
                else if (tempBuf[0] == 'G')
                {
                    tempBuf[0] = '0';
                    Mux = atof(tempBuf);
                    Time.Minutes = uint2bcd(atoi(tempBuf));
                }
                else if (tempBuf[0] == 'H')
                {
                    tempBuf[0] = '0';
                    Mux = atof(tempBuf);
                    Time.Seconds = uint2bcd(atoi(tempBuf));
                }
                else if (tempBuf[0] == 'I')
                {
                    trackingMessage[0] = '\0';
                    snprintf(trackingMessage, sizeof(trackingMessage), "Mem8[0]: %u, Mem8[1]: %u:\r\n",RAM_BUFFER_UINT8[0], RAM_BUFFER_UINT8[1]);
                    USBCDC_sendData((uint8_t*) trackingMessage, sizeof(trackingMessage),CDC0_INTFNUM);
                    snprintf(trackingMessage, sizeof(trackingMessage), "VMem32[0]: %lu, VMem32[1]: %lu:\r\n",(unsigned long int)VRAM_BUFFER_UINT32[0], (unsigned long int)VRAM_BUFFER_UINT32[1]);
                    USBCDC_sendData((uint8_t*) trackingMessage, sizeof(trackingMessage),CDC0_INTFNUM);
                    snprintf(trackingMessage, sizeof(trackingMessage), "Mem16[0]: %u, Mem16[1]: %u:\r\n",(unsigned int)RAM_BUFFER_UINT16[0], (unsigned int)RAM_BUFFER_UINT16[1]);
                    USBCDC_sendData((uint8_t*) trackingMessage, sizeof(trackingMessage),CDC0_INTFNUM);
                }
                else if (tempBuf[0] == 'M')
                {
                    tempBuf[0] = '0';
                    absolutePosAZ= atof(tempBuf);
                    RAM_BUFFER_UINT16[0]=(uint16_t)100.00*absolutePosAZ;
                }
                else if (tempBuf[0] == 'N')
                {
                    tempBuf[0] = '0';
                    absolutePosEL= atof(tempBuf);
                    RAM_BUFFER_UINT16[1]=(uint16_t)100.00*absolutePosEL;
                }

            }

            break; //end case setup

        case MANUAL_AZ:
            if (accepted_mode)
            {

                if (manual_AZ)
                {
                    manual_AZ = 0;
                    deltaAZ = 0;
                    AZ_flag = 0;
                    initial_counterAZ = 0;
                    absDistAZ = 0;
                    absCurrentDistAZ = 0;
                    USBCDC_sendDataInBackground(
                            (uint8_t*) "Manual adjustment AZ : +-10 mm to specify displacement x to stop the motor d to reset the motor\r\n",
                            strlen("Manual adjustment AZ : +-10 mm to specify displacement x to stop the motor d to reset the motor\r\n"),
                            CDC0_INTFNUM,
                            0);
                    MotorAZstop();
                    MotorELstop();

                }

                if (tempBuf[2] == '+' || tempBuf[2] == '-')
                {

                    if ((CornerFlagAZ == 1) && (mv_dir_AZ == '-')
                            && (tempBuf[2] == '-'))
                    {

                        error_num = 1;
                        AZ_flag = 0;

                    }
                    else if ((CornerFlagAZ == 1) && (mv_dir_AZ == '+')
                            && (tempBuf[2] == '+'))
                    {

                        error_num = 2;
                        AZ_flag = 0;

                    }
                    else if ((tempBuf[2] == '+') && (absolutePosAZ >= MaxPosAZ))
                    {
                        error_num = 9;
                        AZ_flag = 0;
                    }
                    else
                    {

                        IntBuf = strtok(tempBuf, " ");
                        AZBuf = strtok(NULL, " ");

                        deltaAZ = atof(AZBuf);

                        if (deltaAZ > (MaxPosAZ - absolutePosAZ))
                        {
                            deltaAZ = MaxPosAZ - absolutePosAZ;
                        }

                        tempBuf[2] = '0';
                        AZ_flag = 1;
                        CornerFlagAZ = 0;
                        error_num = 0;
                    }
                }
            }

            break; //end case manual_AZ

        case MANUAL_EL:
            if (accepted_mode)
            {
                if (manual_EL)
                {
                    deltaEL = 0;
                    manual_EL = 0;
                    EL_flag = 0;
                    initial_counterEL = 0;
                    absDistEL = 0;
                    absCurrentDistEL = 0;
                    USBCDC_sendDataInBackground(
                            (uint8_t*) "Manual adjustment EL : +-10 mm to specify displacement x to stop the motor d to reset the motor\r\n",
                            strlen("Manual adjustment EL : +-10 mm to specify displacement x to stop the motor d to reset the motor\r\n"),
                            CDC0_INTFNUM,
                            0);
                    MotorAZstop();
                    MotorELstop();

                }

                if (tempBuf[2] == '+' || tempBuf[2] == '-')
                {

                    if ((CornerFlagEL == 1) && (mv_dir_EL == '-')
                            && (tempBuf[2] == '-'))
                    {

                        error_num = 1;
                        EL_flag = 0;

                    }
                    else if ((CornerFlagEL == 1) && (mv_dir_EL == '+')
                            && (tempBuf[2] == '+'))
                    {

                        error_num = 2;
                        EL_flag = 0;
                    }
                    else if ((tempBuf[2] == '-') && (absolutePosEL <= MinPosEL))
                    {
                        error_num = 10;
                        AZ_flag = 0;
                    }
                    else
                    {
                        IntBuf = strtok(tempBuf, " ");
                        ELBuf = strtok(NULL, " ");
                        deltaEL = atof(ELBuf);

                        if (deltaEL < 0)
                        {
                            absDistEL = fabs(deltaEL);
                            if (absDistEL > absolutePosEL - MinPosEL)
                            {

                                deltaEL = (-1) * (absolutePosEL - MinPosEL);
                            }
                            absDistEL = 0;

                        }

                        tempBuf[2] = '0';
                        EL_flag = 1;
                        CornerFlagEL = 0;
                        error_num = 0;
                    }
                }
            }

            break; // end case manual_EL

        case MANUAL_BOTH:

            if (accepted_mode)
            {
                if (manual_both)
                {
                    manual_both = 0;
                    AZ_flag = 0;
                    initial_counterAZ = 0;
                    absDistAZ = 0;
                    absCurrentDistAZ = 0;
                    deltaAZ = 0;
                    deltaEL = 0;
                    EL_flag = 0;
                    initial_counterEL = 0;
                    absDistEL = 0;
                    absCurrentDistEL = 0;
                    USBCDC_sendDataInBackground(
                            (uint8_t*) "Manual adjustment of both motors : +-aa.zz,+-ee.ll mm to specify displacement of azimuth and elevation motors, respectively\r\n",
                            strlen("Manual adjustment of both motors : +-aa.zz,+-ee.ll mm to specify displacement of azimuth and elevation motors, respectively\r\n"),
                            CDC0_INTFNUM,
                            0);
                    MotorAZstop();
                    MotorELstop();
                }

                if (tempBuf[2] == '+' || tempBuf[2] == '-')
                {

                    if ((CornerFlagAZ == 1) && (mv_dir_AZ == '-')
                            && (tempBuf[2] == '-'))
                    {

                        error_num = 1;
                        AZ_flag = 0;

                    }
                    else if ((CornerFlagAZ == 1) && (mv_dir_AZ == '+')
                            && (tempBuf[2] == '+'))
                    {

                        error_num = 2;
                        AZ_flag = 0;
                    }
                    else
                    {

                        if (firstTimeBothMoving == true)
                        {
                            firstTimeBothMoving = false;
                        }

                        IntBuf = strtok(tempBuf, " ");
                        AuxBuf = strtok(NULL, " ");

                        AZBuf = strtok(AuxBuf, ",");
                        deltaAZ = atof(AZBuf);

                        if (deltaAZ == 0)
                        {
                            az_moved = 0;
                        }

                        if (deltaAZ > (MaxPosAZ - absolutePosAZ))
                        {
                            deltaAZ = MaxPosAZ - absolutePosAZ;
                        }

                        tempBuf[2] = '0';
                        AZBuf[0] = '0';
                        AZ_flag = 1;
                        CornerFlagAZ = 0;
                        error_num = 0;

                        //The rest of the string is the elevation movement
                        ELBuf = strtok(NULL, ",");

                    }
                }
            }

            break; // end case manual_both
        case STATUS:
            if (accepted_mode)
            {
                if (status)
                {
                    status = 0;
                    MotorAZstop();
                    MotorELstop();

                    //Forming the debugging string (ERRx,POS aa.zz ee.ll)
                    reportMessage[0] = '\0';
                    strncat(reportMessage, "R", 1);
                    sprintf(idString, "%d", RAM_BUFFER_UINT8[0]);
                    strncat(reportMessage, idString, 2);
                    strncat(reportMessage, "B", 1);
                    idString[0] = '\0';
                    sprintf(idString, "%d", motor_block);
                    strncat(reportMessage, idString, 2);
                    strncat(reportMessage, initialString, 3);
                    sprintf(errString, "%d", error_num);
                    strncat(reportMessage, errString, 2);
                    strncat(reportMessage, intermediateString, 4);
                    sprintf(AZString, "%.2f", absolutePosAZ);
                    strncat(reportMessage, AZString, strlen(AZString));
                    strncat(reportMessage, " ", 1);
                    sprintf(ELString, "%.2f", absolutePosEL);
                    strncat(reportMessage, ELString, strlen(ELString));
                    strncat(reportMessage, breakString, 4);

                    USBCDC_sendData((uint8_t*) reportMessage,
                                    strlen(reportMessage),
                                    CDC0_INTFNUM);

                }
            }

            break; // end case status
        default:
            USBCDC_sendDataInBackground((uint8_t*) "Mode not recognized\r\n",
                                        strlen("Mode not recognized\r\n"),
                                        CDC0_INTFNUM,
                                        0);
        } // end Switch mode

        AZ_flag = mesDistMotorAZ(deltaAZ, AZ_flag);

        //Current 1 is only measured if motor 1 is moving
        if (AZ_flag == 1)
        {

            Comp_B_disable(COMP_B_BASE);
            param.positiveTerminalInput = COMP_B_INPUT2; // Enable V+, input channel CB2
            Comp_B_init(COMP_B_BASE, &param);
            Comp_B_configureReferenceVoltage(COMP_B_BASE, &refVoltageParam_Low);
            __delay_cycles(1500);

            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 1 current
            CurrIn1 = Comp_B_outputValue(COMP_B_BASE);

            absDistAZ = fabs(DistAZ);
            absCurrentDistAZ = fabs(CurrentDistAZ);

            //If current is lower than the threshold and there is a pending displacement, we are in a limit
            if ((CurrIn1 == LOW) && (absDistAZ > 0) && (absCurrentDistAZ > 0))
            {
                AZ_flag = 0;
                CornerFlagAZ = 1;
                CurrIn1 = HIGH;
                error_num = 5;
                if (deltaAZ < 0)
                { //returning to home
                    absolutePosAZ = POS_ZERO;
                    CurrentDistAZ = 0;
                }
                else{
                    absolutePosAZ = POS_MAX;
                    CurrentDistAZ = 0;
                }


                if (mode == CALIBRATION)
                {
                    az_calibrated = true;
                }

                if (mode == MANUAL_BOTH)
                {
                    az_moved = 1;

                }
            }

            //If current is higher than the threshold (possible collision), the motor is stopped
            Comp_B_disable(COMP_B_BASE);
            Comp_B_configureReferenceVoltage(COMP_B_BASE,
                                             &refVoltageParam_High);
            __delay_cycles(1500);
            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 1 current
            CurrIn1_H = Comp_B_outputValue(COMP_B_BASE); //Reading CBOUT value
            if (CurrIn1_H == HIGH && absolutePosAZ != POS_ZERO)
            {
                AZ_flag = 0;
                CurrIn1_H = LOW;
                error_num = 7;
                USBCDC_sendDataInBackground(
                        (uint8_t*) "Current higher than expected!!\r\n",
                        strlen("Current higher than expected!!\r\n"),
                        CDC0_INTFNUM,
                        0);

            }
        }

        if (AZ_flag)
        {
            MotorAZmove(deltaAZ);
        }
        else
        {
            MotorAZstop();
            deltaAZ = 0;
            initial_counterAZ = 0;
            absDistAZ = 0;
            absCurrentDistAZ = 0;

            if (az_calibrated == true)
            {

                if (absolutePosEL == POS_MAX && CornerFlagEL == 1) //Calibration not needed; elevation motor is at zero position
                { //do nothing

                }
                else
                {
                    deltaEL = RET_MAX;
                    EL_flag = 1;
                }
                az_calibrated = false;
            }

            if ((mode == MANUAL_BOTH) && (EL_flag == 0)
                    && (firstTimeBothMoving == false)
                    && (accepted_mode == true))
            {
                az_moved = 1;
            }

        }

        if (az_moved == 1)
        {

            if ((CornerFlagEL == 1) && (mv_dir_EL == '-') && (ELBuf[0] == '-'))
            {

                error_num = 1;
                EL_flag = 0;

            }
            else if ((CornerFlagEL == 1) && (mv_dir_EL == '+')
                    && (ELBuf[0] == '+'))
            {

                error_num = 2;
                EL_flag = 0;
            }
            else
            {

                deltaEL = atof(ELBuf);

                if (deltaEL < 0)
                {
                    absDistEL = fabs(deltaEL);
                    if (absDistEL > absolutePosEL - MinPosEL)
                    {

                        deltaEL = (-1) * (absolutePosEL - MinPosEL);
                    }
                    absDistEL = 0;

                }

                ELBuf[0] = '0';
                EL_flag = 1;
                CornerFlagEL = 0;
                error_num = 0;
                az_moved = 0;

            }

        }
        else
        {
            az_moved = 0;
        }

        EL_flag = mesDistMotorEL(deltaEL, EL_flag);

        //Current 2 is only measured if motor 2 is moving
        if (EL_flag == 1)
        {
            Comp_B_disable(COMP_B_BASE);
            param.positiveTerminalInput = COMP_B_INPUT3; //Enable V+, input channel CB3
            Comp_B_init(COMP_B_BASE, &param);
            Comp_B_configureReferenceVoltage(COMP_B_BASE, &refVoltageParam_Low);
            __delay_cycles(1500);

            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 2 current
            CurrIn2 = Comp_B_outputValue(COMP_B_BASE); //Reading CBOUT value
            absDistEL = fabs(DistEL);
            absCurrentDistEL = fabs(CurrentDistEL);

            //If current is lower than the threshold and there is a pending displacement, we are in a limit
            if ((CurrIn2 == LOW) && (absDistEL > 0) && (absCurrentDistEL > 0))
            {
                EL_flag = 0;
                CurrIn2 = HIGH;
                CornerFlagEL = 1;
                error_num = 6;
                if (deltaEL > 0)
                { //returning to home
                    absolutePosEL = POS_MAX;
                    CurrentDistEL = 0;
                }
                else{
                    absolutePosEL = POS_ZERO;
                    CurrentDistEL = 0;
                }

                if (mode == CALIBRATION)
                {
                    error_num = 0;
                }
            }

            //If current is higher than the threshold (possible collision), the motor is stopped
            Comp_B_disable(COMP_B_BASE);
            Comp_B_configureReferenceVoltage(COMP_B_BASE,
                                             &refVoltageParam_High);
            __delay_cycles(1500);
            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 2 current
            CurrIn2_H = Comp_B_outputValue(COMP_B_BASE); //Reading CBOUT value
            if (CurrIn2_H == HIGH && absolutePosEL != POS_MAX)
            {
                EL_flag = 0;
                CurrIn2_H = LOW;
                error_num = 8;
                USBCDC_sendDataInBackground(
                        (uint8_t*) "Current higher than expected!!\r\n",
                        strlen("Current higher than expected!!\r\n"),
                        CDC0_INTFNUM,
                        0);

            }
        }

        if (EL_flag)
        {
            MotorELmove(deltaEL);
        }
        else
        {
            MotorELstop();
            deltaEL = 0;
            initial_counterEL = 0;
            absDistEL = 0;
            absCurrentDistEL = 0;

        }

        if (AZ_flag == 0 && EL_flag == 0)
        {

            memset(tempBuf, 0, BUFFER_SIZE); //cleaning the buffer
            // Check the USB state and directly main loop accordingly
            switch (USB_getConnectionState())
            {
            // This case is executed while your device is enumerated on the
            // USB host
            case ST_ENUM_ACTIVE:
                // Sleep if there are no bytes to process.
                __disable_interrupt();
                if (!USBCDC_getBytesInUSBBuffer(CDC0_INTFNUM))
                {

                    // Enter LPM0 until awakened by an event handler
                    __bis_SR_register(LPM0_bits + GIE);
                }

                __enable_interrupt();

                // Exit LPM because of a data-receive event, and
                // fetch the received data
                if (bCDCDataReceived_event)
                {
                    usb_counter = 0;
                    // Clear flag early -- just in case execution breaks
                    // below because of an error
                    bCDCDataReceived_event = FALSE;

                    usb_counter = USBCDC_receiveDataInBuffer((uint8_t*) tempBuf,
                    BUFFER_SIZE,
                                                             CDC0_INTFNUM);

                }
                break;

            case ST_PHYS_CONNECTED_NOENUM_SUSP:
                __bis_SR_register(LPM3_bits + GIE);
                _NOP();
                break;

            case ST_ENUM_IN_PROGRESS:
            default:
                ;
            }

            id_char = tempBuf[0];

            if (id_char == 'R')
            {

                mode = ChooseMenu(tempBuf[3], &setup, &manual_AZ, &manual_EL,
                                  &manual_both, &status, &calibration);

                id_char = tempBuf[1];
                unique_id = (unsigned short) id_char - '0';

                accepted_mode = false;

                if (RAM_BUFFER_UINT8[0] == unique_id)
                { //movement is done just if we received the proper board ID

                    /*USBCDC_sendData(
                            (uint8_t*) "Communication accepted with PCB ID:",
                            strlen("Communication accepted with PCB ID:"),
                            CDC0_INTFNUM);*/

                    debugString[0] = '\0';
                    sprintf(debugString, "%d", RAM_BUFFER_UINT8[0]);
                    strncat(debugString, breakString, 4);
                    USBCDC_sendData((uint8_t*) debugString, strlen(debugString),
                    CDC0_INTFNUM);

                    accepted_mode = true;

                }
                else
                {
                    /*USBCDC_sendDataInBackground(
                     (uint8_t*) "Incorrect board ID; command rejected\r\n",
                     strlen("Incorrect board ID; command rejected\r\n"),
                     CDC0_INTFNUM,
                     0);*/

                    accepted_mode = false;

                }
            }
            else if (((id_char == '0') || (id_char == '1') || (id_char == '2'))
                    && (RAM_BUFFER_UINT8[0] == unique_id))
            {

                motor_block = id_char - '0';
                accepted_mode = true;
                /*USBCDC_sendData((uint8_t*) "Command applied to motor block:",
                                strlen("Command applied to motor block:"),
                                CDC0_INTFNUM);*/
                debugString[0] = '\0';
                sprintf(debugString, "%d", motor_block);
                strncat(debugString, breakString, 4);
                USBCDC_sendData((uint8_t*) debugString, strlen(debugString),
                CDC0_INTFNUM);

            }
            else
            {
                /*USBCDC_sendDataInBackground(
                 (uint8_t*) "Incorrect board ID; command rejected\r\n",
                 strlen("Incorrect board ID; command rejected\r\n"),
                 CDC0_INTFNUM,
                 0);*/
                if (mode != SETUP)
                {
                    accepted_mode = false;
                }
            }
        }
    } // end while(1)
} // end main()

/*
 * ======== UNMI_ISR ========
 */
#if defined(__TI_COMPILER_VERSION__) || (__IAR_SYSTEMS_ICC__)
#pragma vector = UNMI_VECTOR
__interrupt
void UNMI_ISR(void)
#elif defined(__GNUC__) && (__MSP430__)
 void __attribute__ ((interrupt(UNMI_VECTOR))) UNMI_ISR (void)
 #else
 #error Compiler not found!
 #endif
{
    switch (__even_in_range(SYSUNIV, SYSUNIV_BUSIFG))
    {
    case SYSUNIV_NONE:
        __no_operation();
        break;
    case SYSUNIV_NMIIFG:
        __no_operation();
        break;
    case SYSUNIV_OFIFG:
        UCS_clearFaultFlag(UCS_XT2OFFG);
        UCS_clearFaultFlag(UCS_DCOFFG);
        SFR_clearInterrupt(SFR_OSCILLATOR_FAULT_INTERRUPT);
        break;
    case SYSUNIV_ACCVIFG:
        __no_operation();
        break;
    case SYSUNIV_BUSIFG:
        // If the CPU accesses USB memory while the USB module is
        // suspended, a "bus error" can occur.  This generates an NMI.  If
        // USB is automatically disconnecting in your software, set a
        // breakpoint here and see if execution hits it.  See the
        // Programmer's Guide for more information.
        SYSBERRIV = 0; //clear bus error flag
        USB_disable(); //Disable
    }
}

/*==============================================================================
 * // Description : Timer1 interrupt, which is incremented each ms
 * Parameter(s): -
 * Return      : -
 * ------------------------------------------------------------------------------ */
#pragma vector=TIMER1_A0_VECTOR
__interrupt
void timer1_1ms(void)
{
    static float PrevCurrentDistAZ = 0;
    static float PrevCurrentDistEL = 0;
    static bool sec_counter_AZ = false;
    static bool sec_counter_EL = false;
    static int stop_counter = 0;
    time1ms++;
    ms++;

    if (time1ms >= 10)
    {
        time1ms -= 10;
        time10ms++;
    }
    if (time10ms >= 10)
    {

        time10ms -= 10;
        time100ms++;
        stop_counter++;

        //time100ms2++;
    }

    if (stop_counter >= 10)
    {
        if (AZ_flag == 1)
        {
            if (PrevCurrentDistAZ == CurrentDistAZ) //No movement from previous iteration
            {
                if (sec_counter_AZ == true && az_calibrated == false)
                {
                    AZ_flag = 0;
                    MotorAZstop();
                    absolutePosAZ += CurrentDistAZ;
                    CurrentDistAZ = 0;
                    DistAZ = 0;
                    initial_counterAZ = 0;
                    deltaAZ = 0;

                    error_num = 3; //this error identifies that motor 1 is not receiving Hall pulses

                    EL_flag = 0;
                    MotorELstop();
                    absolutePosEL += CurrentDistEL;
                    CurrentDistEL = 0;
                    DistEL = 0;
                    initial_counterEL = 0;
                    deltaEL = 0;

                }
                else
                {
                    sec_counter_AZ = true;
                }

            }

            else
            {
                PrevCurrentDistAZ = CurrentDistAZ;
                sec_counter_AZ = false;
            }
        }
        else
        {
            PrevCurrentDistAZ = CurrentDistAZ;
            sec_counter_AZ = false;
        }

        if (EL_flag == 1)
        {
            if (PrevCurrentDistEL == CurrentDistEL) //No movement from previous iteration
            {
                if (sec_counter_EL == true)
                {
                    EL_flag = 0;
                    MotorELstop();
                    absolutePosEL += CurrentDistEL;
                    CurrentDistEL = 0;
                    DistEL = 0;
                    initial_counterEL = 0;
                    deltaEL = 0;

                    error_num = 4; //this error identifies that motor 2 is not receiving Hall pulses

                    AZ_flag = 0;
                    MotorAZstop();
                    absolutePosAZ += CurrentDistAZ;
                    CurrentDistAZ = 0;
                    DistAZ = 0;
                    initial_counterAZ = 0;
                    deltaAZ = 0;
                }
                else
                {
                    sec_counter_EL = true;
                }

            }
            else
            {
                PrevCurrentDistEL = CurrentDistEL;
                sec_counter_EL = false;
            }
        }
        else
        {
            PrevCurrentDistEL = CurrentDistEL;
            sec_counter_EL = false;
        }

        stop_counter = 0;
    }

    if (time100ms >= 10)
    {
        time100ms -= 10;
        time1s++;
        sec_counter++;
        P8OUT ^= BIT0;
    }

    /*if (time100ms2 >= 10)
     {
     time100ms2 -= 10;

     }*/

    if (time1s >= 60)
    {
        time1min++;
        time1s -= 60;
    }

    if (sec_counter >= 60)
    {
        min_counter++;
        sec_counter = 0;
    }

    if (time1min >= 60)
    {
        time1h++;
        time1min -= 60;
        min_counter = 0;
        time = 1;
    }
    if (time1h >= 24)
    {
        time1h -= 24;
    }

}


//_____________________________________________________
void readDieRecord(void)
{
  // Read Die Record Values
  TLV_getInfo(TLV_TAG_DIERECORD,
              0,
              &bDieRecord_bytes,
              (uint16_t **)&pDIEREC
              );
  VRAM_BUFFER_UINT32[0] = pDIEREC->wafer_id;
  uint32_t tmp=0x0000FFFF;
  tmp=tmp&((uint32_t)pDIEREC->die_x_position);
  tmp=tmp<<16;
  tmp=tmp|( ((uint32_t)pDIEREC->die_y_position & 0x0000FFFF) );
  VRAM_BUFFER_UINT32[1] = tmp;
}


//------------------------------------------------------------------------------
//Input = value, holds value to write to Seg C
//------------------------------------------------------------------------------
void FLASH_write_SegC ()
{
    uint16_t status;

    RAM_BUFFER_UINT16[0]=(uint16_t)(absolutePosAZ*100.00);
    RAM_BUFFER_UINT16[1]=(uint16_t)(absolutePosEL*100.00);

    //Erase INFOC
    do
    {
        FlashCtl_eraseSegment((uint8_t *)UINT8_FLASH_SC_START);
        status = FlashCtl_performEraseCheck((uint8_t *)UINT32_FLASH_SC_START,
                                            NUMBER_OF_UINT32
            );
    } while (status == STATUS_FAIL);

    //Flash Write
    FlashCtl_write8(RAM_BUFFER_UINT8,(uint8_t *)UINT8_FLASH_SC_START,(uint16_t)NUMBER_OF_UINT8);
    FlashCtl_write16(RAM_BUFFER_UINT16,(uint16_t *)UINT16_FLASH_SC_START,(uint16_t)NUMBER_OF_UINT16);
    FlashCtl_write32(RAM_BUFFER_UINT32,(uint32_t *)UINT32_FLASH_SC_START,(uint16_t)NUMBER_OF_UINT32);
}



