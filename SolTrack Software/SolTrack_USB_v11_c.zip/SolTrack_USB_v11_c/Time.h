/*!
 * \file       Rtc.h
 * \brief      MSP430 RTC_A librairy
 * \author     Manolo Vuarrier
 * \version    1
 * \date       30.08.2021
 */

#ifndef CLOCKS_H_
#define CLOCKS_H_

    //** Includes
    #include <msp430f6636.h>
    #include <stdbool.h>
    #include <stdint.h>
    //#include "Tools.h"

    #define F_ACLK              32768
    #define F_SMCLK             20000000
    #define F_MCLK              10000000
    #define RTC_CYCLIC          (F_MAIN_LOOP / 4)   ///< Fetch time at 2 [Hz]
    #define BAUD_RATE           115200


    /*!
     * \struct sTimeDate
     * \brief Structure containing the time and date (everything is coded in packed BCD)
     */
    typedef struct
    {
        uint8_t Seconds;
        uint8_t Minutes;
        uint8_t Hours;
        uint8_t DayOfWeek;
        uint8_t Date;
        uint8_t Month;
        uint16_t Year;
    }sTimeDate;

    /*!
     * \brief Callback function pointer defintion with void argument
     */
    typedef void (*fCallbackVoid)(void);



    void    InitOscillator(void);
    void    RtcInit(void);
    void    RtcSetCalibration(int16_t clock_ppm);
    void    RtcCyclic(void);

    void    RtcSleep(void);
    void    RtcWakeUp(void);

    void    RtcSetCallBack(fCallbackVoid func);
    void    RtcExecuteCallBack(void);

    void    RtcFetchTime(void);
    void    RtcFetchTimeAndCheck(void);

    void    RtcSetTime(sTimeDate *input);
    void    RtcGetTime(sTimeDate *output);

    uint8_t   RtcGetDays(void);
    uint8_t   RtcGetMonths(void);
    uint8_t   RtcGetYears(void);
    uint8_t   RtcGetHours(void);
    uint8_t   RtcGetMinutes(void);
    uint8_t   RtcGetSeconds(void);

    void    RtcGetTimeString(char *out);
    void    RtcGetTimeToDecimal(sTimeDate *input);

    //void    PowerResetTimer();

    void initTimerA1();

    //Variable globale pour compter les ms
    extern int horloge1ms;
    extern int horloge10ms;
    extern int horloge100ms, horloge100ms2, horloge1s, horloge1min, horloge1h;
    extern int horlogeMvtMot;
    extern int ms;





#endif /* CLOCKS_H_ */
