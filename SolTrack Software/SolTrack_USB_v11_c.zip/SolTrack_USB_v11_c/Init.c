/*
 * init.c
 *
 *  Created on: 28 June 2022
 *      Author: jonat
 *  Last modification on: 11 January 2023.
 *      Author: Yubal Barrios
 */
#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "Init.h"
#include "uart.h"

/*==============================================================================
 * // Description : I/O pins configuration and initialization
 * Parameter(s): -
 * Return      : -
 * ------------------------------------------------------------------------------ */
void initPorts()
{
    //pins configuration
    P3DIR |= BIT4; //Port 3.4 as output
    P3SEL |= BIT4; //Make SMCLK readable on port 3.4

    P5DIR |= BIT4 + BIT3; //LEDs output

    P6DIR &= ~BIT0; //Hall sensor 1 input
    P6DIR &= ~BIT1; //Hall sensor 2 input

}

int uint2bcd(unsigned int ival)
{
    return ((ival / 10) << 4) | (ival % 10);
}

/*==============================================================================
 * // Description : Mode selection
 * Parameter(s): char sel to indicate the desired mode command
 *             : int modes, available modes
 * Return      : MODE mode, the selected mode
 * ------------------------------------------------------------------------------ */

MODE ChooseMenu(char sel, int *setup, int *manual_AZ, int *manual_EL,
                int *manual_both, int *status, int *calibration)
{
    static MODE mode;
    if (sel == 's')
    {
        *setup = 1;
        *manual_AZ = 0;
        *manual_EL = 0;
        *manual_both = 0;
        *status = 0;
        *calibration = 0;
        mode = SETUP;
    }
    else if (sel == 'z')
    {
        *setup = 0;
        *manual_AZ = 1;
        *manual_EL = 0;
        *manual_both = 0;
        *status = 0;
        *calibration = 0;
        mode = MANUAL_AZ;
    }
    else if (sel == 'e')
    {
        *setup = 0;
        *manual_AZ = 0;
        *manual_EL = 1;
        *manual_both = 0;
        *status = 0;
        *calibration = 0;
        mode = MANUAL_EL;
    }
    else if (sel == 'm')
    {
        *setup = 0;
        *manual_AZ = 0;
        *manual_EL = 0;
        *manual_both = 1;
        *status = 0;
        *calibration = 0;
        mode = MANUAL_BOTH;
    }

    else if (sel == 'x')
    {
        *setup = 0;
        *manual_AZ = 0;
        *manual_EL = 0;
        *manual_both = 0;
        *status = 1;
        *calibration = 0;
        mode = STATUS;
    }
    else if (sel == 'c')
    {
        *setup = 0;
        *manual_AZ = 0;
        *manual_EL = 0;
        *manual_both = 0;
        *status = 0;
        *calibration = 1;
        mode = CALIBRATION;
    }
    return mode;

}

