#include <string.h>
#include "driverlib.h"

#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "Init.h"
#include "Time.h"
#include "regul.h"
#include "uart.h"

#define BUFFER_SIZE 32
#define TX_BUFFER_SIZE 200
// DEFINE SIZE OF MEMORY BUFFERS
#define NUMBER_OF_UINT8  9 //size of UINT8 buffer -> max is 9!
#define NUMBER_OF_UINT16 19 //size of UINT8 buffer -> max is 19!
#define NUMBER_OF_UINT32 16 //size of UINT8 buffer -> max is 16!
#define UINT8_FLASH_SC_START   (0x1880)
#define UINT16_FLASH_SC_START   (0x188A) //10 BYTES SPACING WITH UINT8 SEGMENT  (10 UINT8 units)
#define UINT32_FLASH_SC_START   (0x18B2) //40 BYTES SPACING WITH UINT16 SEGMENT (20 UINT16 units) -- max size 77 bytes= 19 UINT32 units
//-----------------------------
#define FW_VERSION 25.2

// GLOBAL UNIQUE IDENTIFIER ___________________________________
struct s_TLV_Die_Record *pDIEREC;
uint8_t bDieRecord_bytes;
uint16_t temp;
void readDieRecord(void);
//--------------------------------------------------------------

// CREATE STORABLE RAM BUFFERS
uint8_t RAM_BUFFER_UINT8[9];
uint16_t RAM_BUFFER_UINT16[19];
uint32_t RAM_BUFFER_UINT32[16];
uint32_t VRAM_BUFFER_UINT32[2];
/////////////
char isELstopped = 1;
char isAZstopped = 1;

void FLASH_write_SegC(void);

sTimeDate Time;

char HallSens1, HallSens2;

int time1ms;
int time10ms;
int time100ms = 0, time100ms2 = 0, time1s = 0, time1min = 0, time1h = 7;
int ms;
int min_counter = 0;
int sec_counter = 0;
int charco = 0;
int isPassedTerminator = 0;
int count = 0;

int dir = 2;
int drapeau = 0;

float CurrentDistEL = 0, CurrentDistAZ = 0;
float DistAZ = 0, DistEL = 0;
float MaxPosAZ = 410.0, MinPosEL = -10.0;
char mv_dir_AZ, mv_dir_EL;

int numberHallPulses = 10;
float HallPulse2mm = 0.1;
float initial_counterAZ = 0, initial_counterEL = 0;
volatile float targetAZ = 0, targetEL = 0;
volatile float deltaEL = 0, distEL, oldDistEL;
volatile float deltaAZ = 0, distAZ, oldDistAZ;
static float absolutePosAZ = 0, absolutePosAZ_2 = 0, absolutePosEL = 400,
        absolutePosEL_2 = 400;
static char motor_block_global;
unsigned short error_num_1 = 0, error_num_2 = 0;
int isSleep;

bool az_calibrated = false;
volatile bool is_newRX_Data = false;
volatile bool is_newString = false;

int EL_flag = 0;
int AZ_flag = 0;

volatile int time = 1;
volatile unsigned int i;

Comp_B_configureReferenceVoltageParam refVoltageParam_Low = { 0 };
Comp_B_configureReferenceVoltageParam refVoltageParam_High = { 0 };
Comp_B_initParam param = { 0 };

volatile char RX_Data[BUFFER_SIZE];
char TX_Data[TX_BUFFER_SIZE] = { '\0' };
;

/*  
 * ======== main ========
 */
void main(void)
{

    /////////////////////////////// NV MEMORY READ-OUT AND INITILIZATION OF NV VARIABLES
    // READ THE FLASH AND SET THE VALUES IN RAM ACCORDINGLY
    memcpy(&RAM_BUFFER_UINT8[0], (uint8_t*) UINT8_FLASH_SC_START,
    NUMBER_OF_UINT8); //copy from UINT8 flash buffer into UINT8 RAM buffer
    memcpy(&RAM_BUFFER_UINT16[0], (uint16_t*) UINT16_FLASH_SC_START,
    NUMBER_OF_UINT16); //copy from UINT16 flash buffer into UINT16 RAM buffer
    memcpy(&RAM_BUFFER_UINT32[0], (uint32_t*) UINT8_FLASH_SC_START,
    NUMBER_OF_UINT32); //copy from UINT32 flash buffer into UINT32 RAM buffer
    /////////////////////////////// DATA FROM FLASH SAVED INTO RAM

    // if the board ID has never been initialized (value 0xff for cleared flash), then we set it to 0.
    if (RAM_BUFFER_UINT8[0] > 9)
    {
        RAM_BUFFER_UINT8[0] = 0x00;
    }

    // if the position has never been initialized we ignore the position
    if (RAM_BUFFER_UINT16[0] != 0xffff)
    {
        absolutePosAZ = ((float) RAM_BUFFER_UINT16[0]) / 100;
    }
    if (RAM_BUFFER_UINT16[1] != 0xffff)
    {
        absolutePosEL = ((float) RAM_BUFFER_UINT16[1]) / 100;
    }
    if (RAM_BUFFER_UINT16[2] != 0xffff)
    {
        absolutePosAZ_2 = ((float) RAM_BUFFER_UINT16[2]) / 100;
    }
    if (RAM_BUFFER_UINT16[3] != 0xffff)
    {
        absolutePosEL_2 = ((float) RAM_BUFFER_UINT16[3]) / 100;
    }
    if (RAM_BUFFER_UINT16[4] != 0xffff)
    {
        HallPulse2mm = ((float) RAM_BUFFER_UINT16[4]) / 100;
    }

    readDieRecord(); // Initializes the two first uint32 bits

    WDTCTL = WDTPW + WDTHOLD;

    InitOscillator();
    RtcInit();

    //------------------------------------------
    volatile float absDistAZ = 0, absDistEL = 0;
    volatile float absCurrentDistAZ, absCurrentDistEL;

    unsigned char unique_id = 0;
    char id_char = 0;
    bool accepted_mode = false;
    static char motor_block;

    int setup, manual_both, status, calibration;
    static unsigned short CurrIn1 = HIGH, CurrIn2 = HIGH;
    static unsigned short CurrIn1_H = LOW, CurrIn2_H = LOW;
    char az_moved = 0;
    char CornerFlagAZ = 0; // Used to know if the motor is at an edge
    char CornerFlagEL = 0; // Used to know if the motor is at an edge
    char reportMessage[100] = { '\0' };
    char *initialString = "ERR";
    char *intermediateString = ",POS";
    char *breakString = "\r\n";
    char debugString[20] = { '\0' };
    char errString[3] = { '\0' };
    char idString[3] = { '\0' };
    char AZString[8] = { '\0' };
    char ELString[8] = { '\0' };
    volatile float Mux = 0;

    volatile float a, b, c, d, e, f, g;

    volatile MODE mode = RESET;
    volatile DATA_SETUP setup_switch = DEFAULT;

    char *IntBuf = { 0 };
    char *TmpBuf = { 0 };
    //memset(IntBuf, 0, BUFFER_SIZE); //cleaning the buffer
    char *AuxBuf = { 0 };
    //memset(AuxBuf, 0, BUFFER_SIZE); //cleaning the buffer
    char *AZBuf = { 0 };
    char *ELBuf = { 0 };

    PMM_setVCore(PMM_CORE_LEVEL_2);

    initPorts();
    initPWM();
    initTimerB0();
    initComparator();
    rs_485_init();

    __enable_interrupt();  // Enable interrupts globally
    TA1CCTL0 &= ~CCIFG;
    TA1CCTL1 &= ~CCIFG;

    TA2CCTL0 &= ~CCIFG;
    TA2CCTL1 &= ~CCIFG;



    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //%%%%%%%%%%   EXECUTE ON REBOOT   %%%%%%%
    sprintf(TX_Data, "REBOOT - COM_ID: %d.\r\n", RAM_BUFFER_UINT8[0]);
                rs_485_send_data((uint8_t*) TX_Data, TX_BUFFER_SIZE);
                memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

    while (1)
    {

        if (time)
        {
            time = 0;
        }

        ////Stop time fetching when in setup mode
        if (mode != SETUP)
        {
            RtcFetchTime();
            RtcGetTime(&Time);
            RtcGetTimeToDecimal(&Time);

        }

        //IF WE HAVE A NEW STRING///
        if (is_newString)
        {

            //START OF THE SWITCH ON THE DIFFERENT OPERATING MODES///
            switch (mode)
            {

            case CALIBRATION:
                if (accepted_mode)
                {
                    if (calibration)
                    {
                        calibration = 0;
                        error_num_1 = 0;
                        error_num_2 = 0;
                        MotorAZstop(motor_block);
                        MotorELstop(motor_block);

                        sprintf(TX_Data,
                                "Returning motors to the initial position\r\n");
                        rs_485_send_data((uint8_t*) TX_Data, TX_BUFFER_SIZE);
                        memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

                        if ((motor_block == 1 && absolutePosAZ <= POS_ZERO)
                                || (motor_block == 2
                                        && absolutePosAZ_2 <= POS_ZERO))
                        {

                            AZ_flag = 0;
                            DistAZ = 0;
                            deltaAZ = 0;
                            az_calibrated = true;
                        }

                        else
                        {

                            deltaAZ = RET_START;
                            AZ_flag = 1;
                            DistAZ = fabs(deltaAZ);

                        }

                    }
                }
                break;

            case SETUP:
                if (accepted_mode)
                {
                    if (setup)
                    {
                        setup = 0;
                        //memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                        sprintf(TX_Data,
                                "FW v.: %.1f - Mode Setup: please provide letter + value: I->PCB Identifier P->POR C->Store config to FLASH H-> Hall distance in mm X->view memory AZx-> AbsPosAZx ELx-> AbsPosELx\r\n",
                                (float) FW_VERSION);
                        rs_485_send_data((uint8_t*) TX_Data, TX_BUFFER_SIZE);
                        memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

                        MotorAZstop(motor_block);
                        MotorELstop(motor_block);
                        drapeau = 0;
                        time1h = 4;
                    }

                    RX_Data[0] = '0';
                    RX_Data[1] = '0';
                    RX_Data[2] = '0';

                    if (RX_Data[3] == 'I')
                    {
                        RX_Data[3] = '0';
                        RAM_BUFFER_UINT8[0] = atoi(RX_Data);
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer
                    }
                    else if (RX_Data[3] == 'P') //PoR: Power on Reset
                    {
                        WDTCTL = 0xDEAD; //RESET

                    }
                    else if (RX_Data[3] == 'C')
                    {
                        FLASH_write_SegC(); // Store the RAM buffers into FLASH segment C.
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if (RX_Data[3] == 'N')
                    {
                        RX_Data[3] = '0';
                        Mux = atof(RX_Data);
                        Time.Month = uint2bcd(atoi(RX_Data));
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if (RX_Data[3] == 'D')
                    {
                        RX_Data[3] = '0';
                        Mux = atof(RX_Data);
                        Time.Date = uint2bcd(atoi(RX_Data));
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if (RX_Data[3] == 'H')
                    {
                        RX_Data[3] = '0';
                        Mux = atof(RX_Data);
                        HallPulse2mm = Mux;
                        RAM_BUFFER_UINT16[4] = (uint16_t) 100.00 * Mux;
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if (RX_Data[3] == 'M')
                    {
                        RX_Data[3] = '0';
                        Mux = atof(RX_Data);
                        Time.Minutes = uint2bcd(atoi(RX_Data));
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if (RX_Data[3] == 'S')
                    {
                        RX_Data[3] = '0';
                        Mux = atof(RX_Data);
                        Time.Seconds = uint2bcd(atoi(RX_Data));
                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if (RX_Data[3] == 'X')
                    {
                        sprintf(TX_Data,
                                "Mem8[0]: %u, Mem8[1]: %u, VMem32[0]: %lu, VMem32[1]: %lu, Mem16[0]: %u, Mem16[1]: %u,Mem16[2]: %u, Mem16[3]: %u,Mem16[4]: %u \r\n",
                                RAM_BUFFER_UINT8[0], RAM_BUFFER_UINT8[1],
                                (unsigned long int) VRAM_BUFFER_UINT32[0],
                                (unsigned long int) VRAM_BUFFER_UINT32[1],
                                (unsigned int) RAM_BUFFER_UINT16[0],
                                (unsigned int) RAM_BUFFER_UINT16[1],
                                (unsigned int) RAM_BUFFER_UINT16[2],
                                (unsigned int) RAM_BUFFER_UINT16[3],
                                (unsigned int) RAM_BUFFER_UINT16[4]);
                        rs_485_send_data((uint8_t*) TX_Data, TX_BUFFER_SIZE);
                        memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer
                    }
                    else if ((RX_Data[3] == 'A') && (RX_Data[4] == 'Z'))
                    {

                        RX_Data[3] = '0';
                        RX_Data[4] = '0';

                        if (RX_Data[5] == '1')
                        {

                            RX_Data[5] = '0';
                            absolutePosAZ = atof(RX_Data);
                            RAM_BUFFER_UINT16[0] = (uint16_t) 100.00
                                    * absolutePosAZ;
                        }
                        else if (RX_Data[5] == '2')
                        {

                            RX_Data[5] = '0';
                            absolutePosAZ_2 = atof(RX_Data);
                            RAM_BUFFER_UINT16[2] = (uint16_t) 100.00
                                    * absolutePosAZ_2;
                        }

                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }
                    else if ((RX_Data[3] == 'E') && (RX_Data[4] == 'L'))
                    {

                        RX_Data[3] = '0';
                        RX_Data[4] = '0';

                        if (RX_Data[5] == '1')
                        {
                            RX_Data[5] = '0';

                            absolutePosEL = atof(RX_Data);
                            RAM_BUFFER_UINT16[1] = (uint16_t) 100.00
                                    * absolutePosEL;
                        }
                        else if (RX_Data[5] == '2')
                        {
                            RX_Data[5] = '0';
                            absolutePosEL_2 = atof(RX_Data);

                            RAM_BUFFER_UINT16[3] = (uint16_t) 100.00
                                    * absolutePosEL_2;
                        }

                        accepted_mode = false;
                        memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                    }

                }

                break; //end case setup

            case MANUAL_BOTH:

                if (accepted_mode)
                {
                    if (manual_both)
                    {
                        manual_both = 0;
                        AZ_flag = 0;
                        initial_counterAZ = 0;
                        absDistAZ = 0;
                        absCurrentDistAZ = 0;
                        CurrentDistAZ = 0;
                        deltaAZ = 0;
                        targetAZ = 0;
                        deltaEL = 0;
                        EL_flag = 0;
                        initial_counterEL = 0;
                        absDistEL = 0;
                        absCurrentDistEL = 0;
                        DistEL = 0;
                        CurrentDistEL = 0;
                        targetEL = 0;
                        az_moved = 0;

                        sprintf(TX_Data,
                                (unsigned char*) "Manual adjustment of both motors : +-aa.zz,+-ee.ll mm to specify displacement of azimuth and elevation motors, respectively\r\n");
                        rs_485_send_data((uint8_t*) TX_Data, TX_BUFFER_SIZE);
                        memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

                        MotorAZstop(motor_block);
                        MotorELstop(motor_block);
                        //memset(RX_Data, 0, BUFFER_SIZE); //cleaning the buffer

                        ELBuf = "";
                        AZBuf = ""; //cleaning the buffer

                    }

                    if (RX_Data[5] == '+' || RX_Data[5] == '-')
                    {

                        IntBuf = strtok(RX_Data, " ");
                        TmpBuf = strtok(NULL, " ");
                        AuxBuf = strtok(NULL, " ");

                        AZBuf = strtok(AuxBuf, ",");

                        targetAZ = atof(AZBuf);

                        if (motor_block == 1)
                        {
                            deltaAZ = targetAZ - absolutePosAZ;
                        }
                        else if (motor_block == 2)
                        {
                            deltaAZ = targetAZ - absolutePosAZ_2;
                        }

                        if (deltaAZ == 0)
                        {
                            az_moved = 0;
                        }

                        if (deltaAZ > (MaxPosAZ - absolutePosAZ))
                        {
                            deltaAZ = MaxPosAZ - absolutePosAZ;
                        }

                        if (deltaAZ > 0)
                        {
                            dir = FWD;
                        }
                        else
                        {
                            dir = BWD;
                        }

                        RX_Data[5] = '0';

                        if (motor_block == 1)
                        {
                            error_num_1 = 0;

                        }
                        else if (motor_block == 2)
                        {
                            error_num_2 = 0;

                        }

                        DistAZ = fabs(deltaAZ);

                        AZString[0] = '\0';

                        //The rest of the string is the elevation movement
                        ELBuf = strtok(NULL, ",");

                        if ((CornerFlagAZ == 1) && (dir == BWD)
                                && (((motor_block == 1)
                                        && ((absolutePosAZ <= 0.1)
                                                && (absolutePosAZ
                                                        > (POS_ZERO - 0.5))))
                                        || ((motor_block == 2)
                                                && ((absolutePosAZ_2 <= 0.1)
                                                        && (absolutePosAZ_2
                                                                > (POS_ZERO
                                                                        - 0.5))))))
                        {

                            if (motor_block == 1)
                            {
                                error_num_1 = 1;

                            }
                            else if (motor_block == 2)
                            {
                                error_num_2 = 1;

                            }
                            AZ_flag = 0;

                        }
                        else if ((CornerFlagAZ == 1) && (dir == FWD)
                                && (((motor_block == 1)
                                        && ((absolutePosAZ >= 399.9)
                                                && (absolutePosAZ
                                                        < (POS_MAX + 0.5))))
                                        || ((motor_block == 2)
                                                && ((absolutePosAZ_2 >= 399.9)
                                                        && (absolutePosAZ_2
                                                                < (POS_MAX + 0.5))))))
                        {

                            if (motor_block == 1)
                            {
                                error_num_1 = 2;

                            }
                            else if (motor_block == 2)
                            {
                                error_num_2 = 2;

                            }
                            AZ_flag = 0;
                        }
                        else
                        {
                            AZ_flag = 1;
                            CornerFlagAZ = 0;

                        }

                    }
                }

                break; // end case manual_both
            case STATUS:
                if (accepted_mode)
                {
                    if (status)
                    {
                        status = 0;
                        MotorAZstop(motor_block);
                        MotorELstop(motor_block);

                        if (motor_block == 0)
                        { //information for both motor blocks is shown
                          //Forming the debugging string (ERRx,POS aa.zz ee.ll)
                            reportMessage[0] = '\0';
                            strncat(reportMessage, "R", 1);
                            sprintf(idString, "%d", RAM_BUFFER_UINT8[0]);
                            strncat(reportMessage, idString, 2);
                            strncat(reportMessage, "B", 1);
                            idString[0] = '\0';
                            sprintf(idString, "%d", 1);
                            strncat(reportMessage, idString, 2);
                            strncat(reportMessage, initialString, 3);
                            sprintf(errString, "%d", error_num_1);
                            strncat(reportMessage, errString, 2);
                            strncat(reportMessage, intermediateString, 4);
                            AZString[0] = '\0';
                            ELString[0] = '\0';
                            sprintf(AZString, "%.2f", absolutePosAZ);
                            strncat(reportMessage, AZString, strlen(AZString));
                            strncat(reportMessage, " ", 1);
                            sprintf(ELString, "%.2f", absolutePosEL);
                            strncat(reportMessage, ELString, strlen(ELString));
                            strncat(reportMessage, " ", 1);
                            strncat(reportMessage, "R", 1);
                            sprintf(idString, "%d", RAM_BUFFER_UINT8[0]);
                            strncat(reportMessage, idString, 2);
                            strncat(reportMessage, "B", 1);
                            idString[0] = '\0';
                            sprintf(idString, "%d", 2);
                            strncat(reportMessage, idString, 2);
                            strncat(reportMessage, initialString, 3);
                            sprintf(errString, "%d", error_num_2);
                            strncat(reportMessage, errString, 2);
                            strncat(reportMessage, intermediateString, 4);
                            AZString[0] = '\0';
                            ELString[0] = '\0';
                            sprintf(AZString, "%.2f", absolutePosAZ_2);
                            strncat(reportMessage, AZString, strlen(AZString));
                            strncat(reportMessage, " ", 1);
                            sprintf(ELString, "%.2f", absolutePosEL_2);
                            strncat(reportMessage, ELString, strlen(ELString));
                            strncat(reportMessage, breakString, 4);

                            sprintf(TX_Data, reportMessage);
                            rs_485_send_data((uint8_t*) TX_Data,
                            TX_BUFFER_SIZE);
                            memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

                        }
                        else
                        {
                            //Forming the debugging string (ERRx,POS aa.zz ee.ll)
                            reportMessage[0] = '\0';
                            strncat(reportMessage, "R", 1);
                            sprintf(idString, "%d", RAM_BUFFER_UINT8[0]);
                            strncat(reportMessage, idString, 2);
                            strncat(reportMessage, "B", 1);
                            idString[0] = '\0';
                            sprintf(idString, "%d", motor_block);
                            strncat(reportMessage, idString, 2);
                            strncat(reportMessage, initialString, 3);

                            if (motor_block == 1)
                            {
                                sprintf(errString, "%d", error_num_1);

                            }
                            else if (motor_block == 2)
                            {
                                sprintf(errString, "%d", error_num_2);

                            }
                            strncat(reportMessage, errString, 2);
                            strncat(reportMessage, intermediateString, 4);

                            AZString[0] = '\0';
                            ELString[0] = '\0';

                            if (motor_block == 1)
                            {
                                sprintf(AZString, "%.2f", absolutePosAZ);
                                strncat(reportMessage, AZString,
                                        strlen(AZString));
                                strncat(reportMessage, " ", 1);
                                sprintf(ELString, "%.2f", absolutePosEL);
                                strncat(reportMessage, ELString,
                                        strlen(ELString));
                            }
                            else if (motor_block == 2)
                            {
                                sprintf(AZString, "%.2f", absolutePosAZ_2);
                                strncat(reportMessage, AZString,
                                        strlen(AZString));
                                strncat(reportMessage, " ", 1);
                                sprintf(ELString, "%.2f", absolutePosEL_2);
                                strncat(reportMessage, ELString,
                                        strlen(ELString));
                            }
                            strncat(reportMessage, breakString, 4);
                            sprintf(TX_Data, reportMessage);
                            rs_485_send_data((uint8_t*) TX_Data,
                            TX_BUFFER_SIZE);
                            memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

                        }
                    }
                }

                break; // end case status
            default:
                /*rs_485_send_data((unsigned char*) "Mode not recognized\r\n",
                 strlen("Mode not recognized\r\n"));
                sprintf(TX_Data, (unsigned char*) "Mode not recognized\r\n");
                rs_485_send_data((uint8_t*) TX_Data,
                TX_BUFFER_SIZE);*/
                memset(TX_Data, 0, TX_BUFFER_SIZE); //cleaning the buffer

            } //  end Switch MODE

            is_newString = 0;

        } //////////////////// ONLY RUN WHEN WE HAVE RECEIVED A FULL NEW STRING

        //Current 1 is only measured if motor 1 is moving
        if (AZ_flag == 1)
        {

            //rs_485_send_data((unsigned char*) "I should move", strlen( "I should move"));

            Comp_B_disable(COMP_B_BASE);

            if (motor_block == 1)
            {
                param.positiveTerminalInput = COMP_B_INPUT2; // Enable V+, input channel CB2
            }
            else if (motor_block == 2)
            {
                param.positiveTerminalInput = COMP_B_INPUT0; // Enable V+, input channel CB0
            }
            Comp_B_init(COMP_B_BASE, &param);
            Comp_B_configureReferenceVoltage(COMP_B_BASE, &refVoltageParam_Low);
            __delay_cycles(1500);

            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 1 current
            CurrIn1 = Comp_B_outputValue(COMP_B_BASE);
            absDistAZ = fabs(DistAZ);

            absCurrentDistAZ = fabs(CurrentDistAZ);

            //If current is lower than the threshold and there is a pending displacement, we are in a limit
            /*if ((CurrIn1 == LOW) && (absDistAZ > 0) && (absCurrentDistAZ > 0))
            {

                AZ_flag = 0;
                DistAZ = 0;
                CornerFlagAZ = 1;
                CurrIn1 = HIGH;
                if (motor_block == 1)
                {
                    error_num_1 = 5;

                }
                else if (motor_block == 2)
                {
                    error_num_2 = 5;

                }
                if (deltaAZ < 0)
                { //returning to home
                    if (motor_block == 1)
                    {
                        absolutePosAZ = POS_ZERO;
                    }
                    else if (motor_block == 2)
                    {
                        absolutePosAZ_2 = POS_ZERO;
                    }
                }
                else
                {
                    if (motor_block == 1)
                    {
                        absolutePosAZ = POS_MAX;
                    }
                    else if (motor_block == 2)
                    {
                        absolutePosAZ_2 = POS_MAX;
                    }
                }

                deltaAZ = 0;
                CurrentDistAZ = 0;

                if (mode == CALIBRATION)
                {
                    az_calibrated = true;
                }

                if (mode == MANUAL_BOTH)
                {
                    az_moved = 1;
                }
            }*/

            //If current is higher than the threshold (possible collision), the motor is stopped
            Comp_B_disable(COMP_B_BASE);
            Comp_B_configureReferenceVoltage(COMP_B_BASE,
                                             &refVoltageParam_High);
            __delay_cycles(1500);
            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 1 current
            /*
            CurrIn1_H = Comp_B_outputValue(COMP_B_BASE); //Reading CBOUT value
            if (CurrIn1_H == HIGH && absolutePosAZ != POS_ZERO)
            {
                AZ_flag = 0;
                CurrIn1_H = LOW;
                if (motor_block == 1)
                {
                    error_num_1 = 7;

                }
                else if (motor_block == 2)
                {
                    error_num_2 = 7;

                }
                rs_485_send_data(
                        (unsigned char*) "Current higher than expected!!\r\n",
                        strlen("Current higher than expected!!\r\n"));

            }*/
        }

        if ((AZ_flag == 1) && (DistAZ > 0))
        {
            MotorAZmove(deltaAZ, motor_block);
            isAZstopped = 0;

        }
        else if ((AZ_flag == 1) && (DistAZ == 0))
        {
            isAZstopped = 0;
            __delay_cycles(1000);

        }
        else
        {
            if (isAZstopped == 0)
            {
                MotorAZstop(motor_block);
                isAZstopped = 1;
                az_moved = 1;
                __delay_cycles(1000);

            }

            deltaAZ = 0;
            initial_counterAZ = 0;
            absDistAZ = 0;
            absCurrentDistAZ = 0;
            CurrentDistAZ = 0;
            AZ_flag = 0;
            DistAZ = 0;
            targetAZ = 0;

            if (az_calibrated == true)
            {

                if (motor_block == 1)
                {
                    if (absolutePosEL == POS_MAX && CornerFlagEL == 1) //Calibration not needed; elevation motor is at zero position
                    { //do nothing

                    }
                    else
                    {
                        deltaEL = RET_MAX;
                        EL_flag = 1;
                        DistEL = fabs(deltaEL);
                    }
                }
                else if (motor_block == 2)
                {
                    if (absolutePosEL_2 == POS_MAX && CornerFlagEL == 1) //Calibration not needed; elevation motor is at zero position
                    { //do nothing

                    }
                    else
                    {
                        deltaEL = RET_MAX;
                        EL_flag = 1;
                        DistEL = fabs(deltaEL);
                    }
                }

                az_calibrated = false;
            }

            /*if ((mode == MANUAL_BOTH) && (absCurrentDistAZ > 0))
             {
             az_moved = 1;
             __delay_cycles(1000);
             }*/

        }

        if (az_moved == 1)
        {

            targetEL = atof(ELBuf);

            if (motor_block == 1)
            {
                deltaEL = targetEL - absolutePosEL;
            }
            else if (motor_block == 2)
            {
                deltaEL = targetEL - absolutePosEL_2;
            }

            /*if (deltaEL < 0)
             {
             absDistEL = fabs(deltaEL);
             if (absDistEL > absolutePosEL - MinPosEL)
             {

             deltaEL = (-1) * (absolutePosEL - MinPosEL);
             }
             absDistEL = 0;

             }*/

            if (deltaEL > 0)
            {
                dir = FWD;
            }
            else
            {
                dir = BWD;
            }

            __delay_cycles(1000);

            if (motor_block == 1)
            {
                error_num_1 = 0;

            }
            else if (motor_block == 2)
            {
                error_num_2 = 0;

            }

            DistEL = fabs(deltaEL);
            az_moved = 0;

            if ((CornerFlagEL == 1) && (dir == BWD)
                    && (((motor_block == 1)
                            && ((absolutePosEL <= 0.1)
                                    && (absolutePosEL > (POS_ZERO - 0.5))))
                            || ((motor_block == 2)
                                    && ((absolutePosEL_2 <= 0.1)
                                            && (absolutePosEL_2
                                                    > (POS_ZERO - 0.5))))))
            {

                if (motor_block == 1)
                {
                    error_num_1 = 1;

                }
                else if (motor_block == 2)
                {
                    error_num_2 = 1;

                }
                EL_flag = 0;

            }
            else if ((CornerFlagEL == 1) && (dir == FWD)
                    && (((motor_block == 1)
                            && ((absolutePosEL >= 399.9)
                                    && (absolutePosEL < POS_MAX + 0.5)))
                            || ((motor_block == 2)
                                    && ((absolutePosEL_2 >= 399.9)
                                            && (absolutePosEL_2 < POS_MAX + 0.5)))))
            {

                if (motor_block == 1)
                {
                    error_num_1 = 2;

                }
                else if (motor_block == 2)
                {
                    error_num_2 = 2;

                }
                EL_flag = 0;
            }
            else
            {
                EL_flag = 1;
                CornerFlagEL = 0;
            }

        }
        else
        {
            az_moved = 0;
        }

        //Current 2 is only measured if motor 2 is moving
        if (EL_flag == 1)
        {

            Comp_B_disable(COMP_B_BASE);

            if (motor_block == 1)
            {
                param.positiveTerminalInput = COMP_B_INPUT3; //Enable V+, input channel CB3
            }
            else if (motor_block == 2)
            {
                param.positiveTerminalInput = COMP_B_INPUT1; // Enable V+, input channel CB1
            }

            Comp_B_init(COMP_B_BASE, &param);
            Comp_B_configureReferenceVoltage(COMP_B_BASE, &refVoltageParam_Low);
            __delay_cycles(1500);

            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);
            //Reading motor 2 current
            CurrIn2 = Comp_B_outputValue(COMP_B_BASE); //Reading CBOUT value
            absDistEL = fabs(DistEL);
            absCurrentDistEL = fabs(CurrentDistEL);

            AZString[0] = '\0';
            debugString[0] = '\0';

            sprintf(AZString, "%d", CurrIn2);
            strncat(debugString, AZString, strlen(AZString));
            strncat(debugString, ",", 1);
            sprintf(AZString, "%.2f", absDistEL);
            strncat(debugString, AZString, strlen(AZString));
            strncat(debugString, ",", 1);
            sprintf(AZString, "%.2f", absCurrentDistEL);
            strncat(debugString, AZString, strlen(AZString));
            strncat(debugString, breakString, strlen(breakString));

            //rs_485_send_data((unsigned char*) debugString, strlen(debugString));

            //If current is lower than the threshold and there is a pending displacement, we are in a limit
            /*if ((CurrIn2 == LOW) && (absDistEL > 0) && (absCurrentDistEL > 0))
            {
                EL_flag = 0;
                DistEL = 0;
                CurrIn2 = HIGH;
                CornerFlagEL = 1;
                if (motor_block == 1)
                {
                    error_num_1 = 6;

                }
                else if (motor_block == 2)
                {
                    error_num_2 = 6;

                }
                if (deltaEL > 0)
                { //returning to home
                    if (motor_block == 1)
                    {
                        absolutePosEL = POS_MAX;
                    }
                    else if (motor_block == 2)
                    {
                        absolutePosEL_2 = POS_MAX;
                    }
                }
                else
                {
                    if (motor_block == 1)
                    {
                        absolutePosEL = POS_ZERO;
                    }
                    else if (motor_block == 2)
                    {
                        absolutePosEL_2 = POS_ZERO;
                    }
                }

                CurrentDistEL = 0;
                deltaEL = 0;

                if (mode == CALIBRATION)
                {
                    if (motor_block == 1)
                    {
                        error_num_1 = 0;

                    }
                    else if (motor_block == 2)
                    {
                        error_num_2 = 0;

                    }
                }
            }*/

            //If current is higher than the threshold (possible collision), the motor is stopped
            Comp_B_disable(COMP_B_BASE);
            Comp_B_configureReferenceVoltage(COMP_B_BASE,
                                             &refVoltageParam_High);
            __delay_cycles(1500);
            //Allow power to Comparator module
            Comp_B_enable(COMP_B_BASE);

            //Reading motor 2 current
            /*
            CurrIn2_H = Comp_B_outputValue(COMP_B_BASE); //Reading CBOUT value
            if (CurrIn2_H == HIGH && absolutePosEL != POS_MAX)
            {
                EL_flag = 0;
                CurrIn2_H = LOW;
                if (motor_block == 1)
                {
                    error_num_1 = 8;

                }
                else if (motor_block == 2)
                {
                    error_num_2 = 8;

                }
                rs_485_send_data(
                        (unsigned char*) "Current higher than expected!!\r\n",
                        strlen("Current higher than expected!!\r\n"));

            }*/
        }

        if ((EL_flag == 1) && (DistEL > 0))
        {
            MotorELmove(deltaEL, motor_block);
            isELstopped = 0;

            if (mode == CALIBRATION)
            {
                if ((motor_block == 1 && absolutePosEL >= POS_MAX)
                        || (motor_block == 2 && absolutePosEL_2 >= POS_MAX))
                {
                    rs_485_send_data((unsigned char*) "EL motor calibrated\r\n",
                                     strlen("EL motor calibrated\r\n"));
                    EL_flag = 0;
                    DistEL = 0;
                }

            }

        }
        else
        {

            if (isELstopped == 0)
            {
                MotorELstop(motor_block);
                isELstopped = 1;
                motor_block = 0;
                motor_block_global = motor_block;
            }

            deltaEL = 0;
            initial_counterEL = 0;
            absDistEL = 0;
            CurrentDistEL = 0;
            EL_flag = 0;
            DistEL = 0;
            targetEL = 0;

        }

        if (AZ_flag == 0 && EL_flag == 0)
        {

            //new string
            if (is_newRX_Data)
            {
                is_newRX_Data = 0;

                //remove termination characters

                isPassedTerminator = 0;
                for (charco = 0; charco < BUFFER_SIZE; charco++)
                {
                    if ((RX_Data[charco] == '\r') || (isPassedTerminator))
                    {
                        isPassedTerminator = 1;
                    }
                    if (isPassedTerminator)
                    {
                        RX_Data[charco] = '\0';
                    }
                }
                isPassedTerminator = 0;
                ////////////////////////////////////

                id_char = RX_Data[0];

                if (id_char == 'R')
                {

                    mode = ChooseMenu(RX_Data[3], &setup, &manual_both, &status,
                                      &calibration);

                    if (RX_Data[3] == 'c')
                    { //calibration mode
                        motor_block = RX_Data[5] - '0';
                        motor_block_global = motor_block;
                    }
                    else if (RX_Data[3] == 'x')
                    {
                        //status mode
                        motor_block = RX_Data[5] - '0';
                        motor_block_global = motor_block;
                    }

                    else if ((RX_Data[3] == '1') || (RX_Data[3] == '2'))
                    {
                        //status mode
                        motor_block = RX_Data[3] - '0';
                        motor_block_global = motor_block;
                    }

                    id_char = RX_Data[1];
                    unique_id = (unsigned short) id_char - '0';

                    accepted_mode = false;

                    if (unique_id == RAM_BUFFER_UINT8[0])
                    { //movement is done just if we received the proper board ID
                        accepted_mode = true;
                    }
                    else
                    {

                        accepted_mode = false;

                    }
                }
                /*else if (((id_char == '0') || (id_char == '1')
                 || (id_char == '2'))
                 && (unique_id == RAM_BUFFER_UINT8[0]))
                 {
                 motor_block = id_char - '0';
                 motor_block_global = motor_block;
                 accepted_mode = true;

                 }*/
                else
                {

                    if (mode != SETUP)
                    {
                        accepted_mode = false;
                    }
                } //end else
                is_newRX_Data = false;
                is_newString = 1;     //if new string

            }     //end isNewData
        }     //end if all mvmt done
    } // end while(1)
} // end main()

void readDieRecord(void)
{
// Read Die Record Values
    TLV_getInfo(TLV_TAG_DIERECORD, 0, &bDieRecord_bytes, (uint16_t**) &pDIEREC);
    VRAM_BUFFER_UINT32[0] = pDIEREC->wafer_id;
    uint32_t tmp = 0x0000FFFF;
    tmp = tmp & ((uint32_t) pDIEREC->die_x_position);
    tmp = tmp << 16;
    tmp = tmp | (((uint32_t) pDIEREC->die_y_position & 0x0000FFFF));
    VRAM_BUFFER_UINT32[1] = tmp;
}

//------------------------------------------------------------------------------
//Input = value, holds value to write to Seg C
//------------------------------------------------------------------------------
void FLASH_write_SegC()
{
    uint16_t status;

    RAM_BUFFER_UINT16[0] = (uint16_t) (absolutePosAZ * 100.00);
    RAM_BUFFER_UINT16[1] = (uint16_t) (absolutePosEL * 100.00);
    RAM_BUFFER_UINT16[2] = (uint16_t) (absolutePosAZ_2 * 100.00);
    RAM_BUFFER_UINT16[3] = (uint16_t) (absolutePosEL_2 * 100.00);

//Erase INFOC
    do
    {
        FlashCtl_eraseSegment((uint8_t*) UINT8_FLASH_SC_START);
        status = FlashCtl_performEraseCheck((uint8_t*) UINT32_FLASH_SC_START,
        NUMBER_OF_UINT32);
    }
    while (status == STATUS_FAIL);

//Flash Write
    FlashCtl_write8(RAM_BUFFER_UINT8, (uint8_t*) UINT8_FLASH_SC_START,
                    (uint16_t) NUMBER_OF_UINT8);
    FlashCtl_write16(RAM_BUFFER_UINT16, (uint16_t*) UINT16_FLASH_SC_START,
                     (uint16_t) NUMBER_OF_UINT16);
    FlashCtl_write32(RAM_BUFFER_UINT32, (uint32_t*) UINT32_FLASH_SC_START,
                     (uint16_t) NUMBER_OF_UINT32);
}

/*==============================================================================
 * // Description : Timer1 interrupt, which is incremented each ms
 * Parameter(s): -
 * Return      : -
 * ------------------------------------------------------------------------------ */
#pragma vector=TIMER0_B0_VECTOR
__interrupt
void timer1_1ms(void)
{
    static float PrevCurrentDistAZ = 0;
    static float PrevCurrentDistEL = 0;
    static bool sec_counter_AZ = false;
    static bool sec_counter_EL = false;
    static int stop_counter = 0;
    time1ms++;
    ms++;

    if (time1ms >= 10)
    {
        time1ms -= 10;
        time10ms++;
    }
    if (time10ms >= 10)
    {

        time10ms -= 10;
        time100ms++;
        stop_counter++;

    }

    if (stop_counter >= 10)
    {
        if (AZ_flag == 1)
        {

            if (motor_block_global == 1)
            {

                if (PrevCurrentDistAZ == absolutePosAZ) //No movement from previous iteration
                {
                    if (sec_counter_AZ == true && az_calibrated == false)
                    {
                        AZ_flag = 0;
                        MotorAZstop(motor_block_global);

                        error_num_1 = 3; //this error identifies that motor 1 is not receiving Hall pulses

                        CurrentDistAZ = 0;
                        DistAZ = 0;
                        initial_counterAZ = 0;
                        deltaAZ = 0;

                        EL_flag = 0;
                        MotorELstop(motor_block_global);

                    }
                    else
                    {
                        sec_counter_AZ = true;
                    }

                }

                else
                {
                    PrevCurrentDistAZ = absolutePosAZ;
                    sec_counter_AZ = false;
                }

            }
            else if (motor_block_global == 2)
            {

                if (PrevCurrentDistAZ == absolutePosAZ_2) //No movement from previous iteration
                {
                    if (sec_counter_AZ == true && az_calibrated == false)
                    {
                        AZ_flag = 0;
                        MotorAZstop(motor_block_global);

                        error_num_2 = 3; //this error identifies that motor 1 is not receiving Hall pulses

                        CurrentDistAZ = 0;
                        DistAZ = 0;
                        initial_counterAZ = 0;
                        deltaAZ = 0;

                        EL_flag = 0;
                        MotorELstop(motor_block_global);

                    }
                    else
                    {
                        sec_counter_AZ = true;
                    }

                }

                else
                {
                    PrevCurrentDistAZ = absolutePosAZ_2;
                    sec_counter_AZ = false;
                }

            }

        }
        else
        {
            if (motor_block_global == 1)
            {
                PrevCurrentDistAZ = absolutePosAZ;
            }
            else if (motor_block_global == 2)
            {
                PrevCurrentDistAZ = absolutePosAZ_2;
            }

            sec_counter_AZ = false;
        }

        if (EL_flag == 1)
        {

            if (motor_block_global == 1)
            {
                if (PrevCurrentDistEL == absolutePosEL) //No movement from previous iteration
                {
                    if (sec_counter_EL == true)
                    {
                        EL_flag = 0;
                        MotorELstop(motor_block_global);

                        error_num_1 = 4; //this error identifies that motor 2 is not receiving Hall pulses

                        CurrentDistEL = 0;
                        DistEL = 0;
                        initial_counterEL = 0;
                        deltaEL = 0;

                        AZ_flag = 0;
                        MotorAZstop(motor_block_global);
                    }
                    else
                    {
                        sec_counter_EL = true;
                    }

                }
                else
                {
                    PrevCurrentDistEL = absolutePosEL;
                    sec_counter_EL = false;
                }
            }

            else if (motor_block_global == 2)
            {

                if (PrevCurrentDistEL == absolutePosEL_2) //No movement from previous iteration
                {
                    if (sec_counter_EL == true)
                    {
                        EL_flag = 0;
                        MotorELstop(motor_block_global);

                        error_num_2 = 4; //this error identifies that motor 2 is not receiving Hall pulses

                        CurrentDistEL = 0;
                        DistEL = 0;
                        initial_counterEL = 0;
                        deltaEL = 0;

                        AZ_flag = 0;
                        MotorAZstop(motor_block_global);
                    }
                    else
                    {
                        sec_counter_EL = true;
                    }

                }
                else
                {
                    PrevCurrentDistEL = absolutePosEL_2;
                    sec_counter_EL = false;
                }

            }

        }

        else
        {
            if (motor_block_global == 1)
            {
                PrevCurrentDistEL = absolutePosEL;
            }
            else if (motor_block_global == 2)
            {
                PrevCurrentDistEL = absolutePosEL_2;
            }

            sec_counter_EL = false;
        }

        stop_counter = 0;
    }

    if (time100ms >= 10)
    {
        time100ms -= 10;
        time1s++;
        sec_counter++;
        P8OUT ^= BIT0;
    }

    if (time1s >= 60)
    {
        time1min++;
        time1s -= 60;
    }

    if (sec_counter >= 60)
    {
        min_counter++;
        sec_counter = 0;
    }

    if (time1min >= 60)
    {
        time1h++;
        time1min -= 60;
        min_counter = 0;
        time = 1;
    }
    if (time1h >= 24)
    {
        time1h -= 24;
    }

}

#pragma vector=TIMER1_A0_VECTOR
__interrupt
void timerA1_M3_CCR0(void)
{

    if (motor_block_global == 2 && AZ_flag)
    {
        if (dir == FWD)
        {
            GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN1);
            GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN2);

        }
        else
        {

            GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN2);
            GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN1);
        }
    }
    else
    {

        GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN1);
        GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN2);
    }
    TA1CCTL0 &= ~CCIFG;

}

#pragma vector=TIMER1_A1_VECTOR
__interrupt
void timerA1_M3_CCR1(void)
{
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN1);
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN2);

    TA1CCTL1 &= ~CCIFG;

}

#pragma vector=TIMER2_A0_VECTOR
__interrupt
void timerA2_M4_CCR0(void)
{

    if (motor_block_global == 2 && EL_flag)
    {
        if (dir == FWD)
        {
            GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN5);
            GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN6);

        }
        else
        {

            GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN6);
            GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN5);
        }
    }
    else
    {

        GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN5);
        GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN6);
    }
    TA2CCTL0 &= ~CCIFG;

}

#pragma vector=TIMER2_A1_VECTOR
__interrupt
void timerA2_M4_CCR1(void)
{

    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN5);
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN6);

    TA2CCTL1 &= ~CCIFG;

}

/*==============================================================================
 * // Description : Hall1 interrupt, which is incremented step by step
 * Parameter(s): -
 * Return      : -
 * ------------------------------------------------------------------------------ */
#pragma vector=PORT1_VECTOR
__interrupt
void Hall_counter_1(void)
{

    GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN3);

    if ((AZ_flag == 1) && (motor_block_global == 1))
    {
        if (dir == FWD)
        {
            absolutePosAZ += HallPulse2mm; // we are counting 0.1 mm
            mv_dir_AZ = '+';
            CurrentDistAZ += HallPulse2mm;

        }

        if (dir == BWD) //dir = BWD
        {
            absolutePosAZ -= HallPulse2mm;
            mv_dir_AZ = '-';
            CurrentDistAZ -= HallPulse2mm;

        }
        DistAZ -= HallPulse2mm;

    }

    else if ((EL_flag == 1) && (motor_block_global == 1))
    {
        if (dir == FWD)
        {
            absolutePosEL += HallPulse2mm; // we are counting 0.1 mm
            mv_dir_EL = '+';
            CurrentDistEL += HallPulse2mm;

        }

        if (dir == BWD) //dir = BWD
        {
            absolutePosEL -= HallPulse2mm;
            mv_dir_EL = '-';
            CurrentDistEL -= HallPulse2mm;
        }
        DistEL -= HallPulse2mm;

    }

    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN3);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN2);

//__delay_cycles(1500);

    GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN3);

}

/*==============================================================================
 * // Description : Hall1 interrupt, which is incremented step by step
 * Parameter(s): -
 * Return      : -
 * ------------------------------------------------------------------------------ */
#pragma vector=PORT3_VECTOR
__interrupt
void Hall_counter_2(void)
{

    GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN4);

    if ((AZ_flag == 1) && (motor_block_global == 2))
    {
        if (dir == FWD)
        {
            absolutePosAZ_2 += HallPulse2mm; // we are counting 0.1 mm
            mv_dir_AZ = '+';
            CurrentDistAZ += HallPulse2mm;

        }

        if (dir == BWD) //dir = BWD
        {
            absolutePosAZ_2 -= HallPulse2mm;
            mv_dir_AZ = '-';
            CurrentDistAZ -= HallPulse2mm;
        }
        DistAZ -= HallPulse2mm;

    }

    else if ((EL_flag == 1) && (motor_block_global == 2))
    {
        if (dir == FWD)
        {
            absolutePosEL_2 += HallPulse2mm; // we are counting 0.1 mm
            mv_dir_EL = '+';
            CurrentDistEL += HallPulse2mm;

        }

        if (dir == BWD) //dir = BWD
        {
            absolutePosEL_2 -= HallPulse2mm;
            mv_dir_EL = '-';
            CurrentDistEL -= HallPulse2mm;
        }
        DistEL -= HallPulse2mm;
    }

    GPIO_clearInterrupt(GPIO_PORT_P3, GPIO_PIN3);
    GPIO_clearInterrupt(GPIO_PORT_P3, GPIO_PIN7);

//__delay_cycles(1500);

    GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN4);

}

#if defined(__MSP430_HAS_USCI_A1__)
#pragma vector=USCI_A1_VECTOR
__interrupt
void USCI_A1_ISR(void)
{

    switch (__even_in_range(UCA1IV, 4))
    {
    case 0: // Vector 0 - no interrupt
        break;

    case 2: // Vector 2 - RXIFG

        RX_Data[count] = USCI_A_UART_receiveData(USCI_A1_BASE);
        if (count >= 2)
        {
            if ((RX_Data[count] == '\n') && (RX_Data[count - 1] == '\r'))
            {
                is_newRX_Data = true;
                count = BUFFER_SIZE;
            }

        }
        if (count == BUFFER_SIZE)
        {
            count = 0;
        }
        else
        {
            count++;
        }
        HWREG8(USCI_A1_BASE + OFS_UCAxIFG) &= ~UCRXIFG;

        break;

    case 4:
        break;

    default:
        break;
    }
}
#endif

