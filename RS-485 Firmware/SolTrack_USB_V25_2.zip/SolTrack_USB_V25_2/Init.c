/*
 * init.c
 *
 *  Created on: 28 June 2022
 *      Author: jonat
 *  Last modification on: 29 September 2023
 *      Author: Yubal Barrios
 */

#include <msp430.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "Init.h"
#include "driverlib.h"
#include "uart.h"

/*==============================================================================
 * // Description : I/O pins configuration and initialization
 * Parameter(s): -
 * Return      : -
 * ------------------------------------------------------------------------------ */
void initPorts()
{
    //pins configuration
    P3DIR |= BIT4; //Port 3.4 as output
    P3SEL |= BIT4; //Make SMCLK readable on port 3.4

    P5DIR |= BIT4 + BIT3 + BIT2 + BIT5; //LEDs output

    /*P1DIR &= ~BIT3; //Hall sensor 1 input
     P1DIR &= ~BIT2; //Hall sensor 2 input
     P1SEL &= ~BIT2;
     P1SEL &= ~BIT3;*/

    GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN3); //Hall sensor 1 input
    GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN2); //Hall sensor 2 input

    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN3);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN2);

    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN3,
    GPIO_LOW_TO_HIGH_TRANSITION);

    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN2,
    GPIO_LOW_TO_HIGH_TRANSITION);

    GPIO_setAsInputPin(GPIO_PORT_P3, GPIO_PIN3); //Hall sensor 3 input
    GPIO_setAsInputPin(GPIO_PORT_P3, GPIO_PIN7); //Hall sensor 4 input

    GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN3);
    GPIO_enableInterrupt(GPIO_PORT_P3, GPIO_PIN7);

    GPIO_selectInterruptEdge(GPIO_PORT_P3, GPIO_PIN3,
    GPIO_LOW_TO_HIGH_TRANSITION);

    GPIO_selectInterruptEdge(GPIO_PORT_P3, GPIO_PIN7,
    GPIO_LOW_TO_HIGH_TRANSITION);
}

int uint2bcd(unsigned int ival)
{
    return ((ival / 10) << 4) | (ival % 10);
}

/*==============================================================================
 * // Description : Mode selection
 * Parameter(s): char sel to indicate the desired mode command
 *             : int modes, available modes
 * Return      : MODE mode, the selected mode
 * ------------------------------------------------------------------------------ */

MODE ChooseMenu(char sel, int *setup,  int *manual_both, int *status, int *calibration)
{
    static MODE mode;
    if (sel == 's')
    {
        *setup = 1;
        *manual_both = 0;
        *status = 0;
        *calibration = 0;
        mode = SETUP;
    }
    else if (sel == 'm')
    {
        *setup = 0;
        *manual_both = 1;
        *status = 0;
        *calibration = 0;
        mode = MANUAL_BOTH;
    }

    else if (sel == 'x')
    {
        *setup = 0;
        *manual_both = 0;
        *status = 1;
        *calibration = 0;
        mode = STATUS;
    }
    else if (sel == 'c')
    {
        *setup = 0;
        *manual_both = 0;
        *status = 0;
        *calibration = 1;
        mode = CALIBRATION;
    }
    return mode;

}

