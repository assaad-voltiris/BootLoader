/*
 * regul.h
 *
 *  Created on: 6 July 2022
 *      Author: jonat
 *  Last modification on: 29 September 2023
 *      Author: Yubal Barrios
 */

#ifndef REGUL_H_
#define REGUL_H_

#include <comp_b.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gpio.h"


#define KT          0.069       //constante de couple [Nm/A]
#define KF          0.0023      //rapport entre la force et le courant
#define P           0.00010909  //rapport en vitesse angulaire et lin�aire
#define DEUXPI      6.2832
#define M_REFLECT   3           // Poid que dois pousser un moteur
                                // Un r�flecteur fait 9kg. 3kg est une grosse approximation


#define VMAX        5
#define INV_VMAX    0.2
#define TMOV_MS     300
#define T1_MS       100
#define T2_MS       200
#define T3_MS       300
#define T1_S        1
#define T2_S        2
#define T2_S_INV    0.5
#define T3_S        3
#define CM_TO_STEP  100
#define MM_TO_STEP  10
#define TOTAL_STEP  4000
#define RET_START   -400
#define RET_MAX   +400
#define POS_ZERO    0.0
#define POS_MAX    400.0


#define UPPER_TRIGG 3200
#define LOWER_TRIGG 200
#define LOW         0
#define HIGH        1
#define FWD         1
#define BWD         0


#define AZ_GAIN         1.41   //mm/� -> 1.22 avant
#define EL_GAIN         2.94   //mm/� -> 2.74 avant
#define EL_AZ_COUPLING  0.35 //�/mm -> 0.28571 avant

#define EL_MIN 15
#define AZ_MAX 300

#define PWM_PERIOD      (1000-1)     //PWM Period = int/SMCLK = 500/20e6 = 25us
#define PWM_DC          50         //50% PWM
#define UIN             24         //Tension moteur de 24V
#define KU              0.069

//Variable speed control (max value = PWM_PERIOD)
#define HIGH_SPEED (PWM_PERIOD*0.9)
#define MEDIUM_SPEED (PWM_PERIOD*0.8)
#define LOW_SPEED (PWM_PERIOD*0.7)
#define STOP_SPEED (PWM_PERIOD*0.7)

#define PWM_PERIOD_2      (1200-1)
#define HIGH_SPEED_2 (PWM_PERIOD_2*0.9)
#define MEDIUM_SPEED_2 (PWM_PERIOD_2*0.8)
#define LOW_SPEED_2 (PWM_PERIOD_2*0.7)
#define STOP_SPEED_2 (PWM_PERIOD_2*0.7)

#define PWM_PERIOD_3      (1500-1)
#define HIGH_SPEED_3 (PWM_PERIOD_3*0.9)
#define MEDIUM_SPEED_3 (PWM_PERIOD_3*0.8)
#define LOW_SPEED_3 (PWM_PERIOD_3*0.7)
#define STOP_SPEED_3 (PWM_PERIOD_3*0.7)

#define START_COUNTER 10
//----------------------


int mesDistMotorAZ(float deltaAZ, int AZFlag, char motor_block);
int mesDistMotorEL(float deltaEL, int ELFlag, char motor_block);

void MotorAZmove(float deltaAZ, char motor_block);
void MotorELmove(float deltaEL, char motor_block);
void MotorAZstop(char motor_block);
void MotorELstop(char motor_block);

void initPWM();
void initComparator();

extern int dir;
extern float AZ_gain, EL_gain, Mec_coupling;
extern int numberHallPulses;
extern float HallPulse2mm;
extern float DistAZ, DistEL;
extern float initial_counterAZ, initial_counterEL;
extern unsigned short CurrIn1, CurrIn2;
extern char mv_dir_AZ, mv_dir_EL;
extern Comp_B_configureReferenceVoltageParam refVoltageParam_Low;
extern Comp_B_configureReferenceVoltageParam refVoltageParam_High;
extern Comp_B_initParam param;


#endif /* REGUL_H_ */
