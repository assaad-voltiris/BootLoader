/*!
 * \file       Rtc.h
 * \brief      MSP430 RTC_A librairy
 * \author     Manolo Vuarrier
 * \version    1
 * \date       30.08.2021
 *
 *  Last modification on: 29 September 2023.
 *  Author: Yubal Barrios
 */


#ifndef CLOCKS_H_
#define CLOCKS_H_

//** Includes
#include <msp430f6636.h>
#include <stdbool.h>
#include <stdint.h>
#include    "ucs.h"
//#include "Tools.h"

#define F_ACLK              32768
#define F_SMCLK             16000000
#define F_MCLK              8000000
#define RTC_CYCLIC          (F_MAIN_LOOP / 4)   ///< Fetch time at 2 [Hz]
#define BAUD_RATE           115200

// Timer A1 Settings - Used for XT2 Frequency Auto Detect
#define TIMER_CTL           TA1CTL
#define TIMER_CTL_SETTINGS  TASSEL_2 + MC_2 + CNTL_0
#define TIMER_CTL_CLR       TACLR
#define TIMER_CCTL          TA1CCTL2
#define TIMER_CCTL_SETTINGS CM_1 + CCIS_1+ CAP
#define TIMER_CCTL_IFG      CCIFG
#define TIMER_CCTL_CM       CM_1
#define TIMER_CCR           TA1R

//24MHz will be detected
#define AUTO_DETECT_XT2_SPEED_1          24000000

//16MHz will be detected
#define AUTO_DETECT_XT2_SPEED_2          16000000

//12MHz will be detected
#define AUTO_DETECT_XT2_SPEED_3          12000000

//8MHz will be detected
#define AUTO_DETECT_XT2_SPEED_4          8000000

//4MHz will be detected
#define AUTO_DETECT_XT2_SPEED_5          4000000

#define REFO_CLK_FREQ                   32768

/*!
 * \struct sTimeDate
 * \brief Structure containing the time and date (everything is coded in packed BCD)
 */
typedef struct
{
    uint8_t Seconds;
    uint8_t Minutes;
    uint8_t Hours;
    uint8_t DayOfWeek;
    uint8_t Date;
    uint8_t Month;
    uint16_t Year;
} sTimeDate;

/*!
 * \brief Callback function pointer defintion with void argument
 */
typedef void (*fCallbackVoid)(void);

void InitOscillator(void);
void RtcInit(void);
void RtcSetCalibration(int16_t clock_ppm);
void RtcCyclic(void);

void RtcSleep(void);
void RtcWakeUp(void);

void RtcSetCallBack(fCallbackVoid func);
void RtcExecuteCallBack(void);

void RtcFetchTime(void);
void RtcFetchTimeAndCheck(void);

void RtcSetTime(sTimeDate *input);
void RtcGetTime(sTimeDate *output);

uint8_t RtcGetDays(void);
uint8_t RtcGetMonths(void);
uint8_t RtcGetYears(void);
uint8_t RtcGetHours(void);
uint8_t RtcGetMinutes(void);
uint8_t RtcGetSeconds(void);

void clock_init();
void RtcGetTimeString(char *out);
void RtcGetTimeToDecimal(sTimeDate *input);

//void    PowerResetTimer();

void initTimerB0();

//Variable globale pour compter les ms
extern int horloge1ms;
extern int horloge10ms;
extern int horloge100ms, horloge100ms2, horloge1s, horloge1min, horloge1h;
extern int horlogeMvtMot;
extern int ms;

#endif /* CLOCKS_H_ */
