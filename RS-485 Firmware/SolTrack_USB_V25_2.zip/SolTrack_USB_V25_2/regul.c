/*
 * regul.c
 *
 *  Created on: 6 July 2022
 *      Author: jonat
 *  Last modification on: 29 September 2023.
 *      Author: Yubal Barrios
 */

#include <msp430.h>
#include "Time.h"
#include "regul.h"
#include "Init.h"


/*==============================================================================
 * Description : Displacement of azimuth motors (motors 1 and 3)
 *              //                MSP430F66xx
 *            -----------------
 *        /|\|             P1.6|--|
 *         | |                 | MOT1, AZ
 *         --|RST          P1.7|--|
 *           |                 |
 *           |             P1.3|<-- HallSens1
 *           |                 |
 *           |             P3.1|--|
 *           |                 | MOT3, AZ
 *           |             P3.2|--|
 *           |                 |
 *           |             P3.3|<-- HallSens3
 *
 * Parameter(s): double deltaAZ, distance in mm
 * Return      :
 * ------------------------------------------------------------------------------ */
void MotorAZmove(float deltaAZ, char motor_block)
{

    int D;
    int D_aux;
    int absDistAZ = fabs(DistAZ);

    if (initial_counterAZ < START_COUNTER)
    {
        D = LOW_SPEED;
        D_aux = LOW_SPEED_2;
        initial_counterAZ += 0.1;
    }

    else if (absDistAZ >= 25)
    {

        D = HIGH_SPEED;
        D_aux = HIGH_SPEED_2;

    }
    else if (absDistAZ >= 8)
    {
        D = MEDIUM_SPEED;
        D_aux = MEDIUM_SPEED_2;
    }
    else
    {
        D = STOP_SPEED;
        D_aux = STOP_SPEED_2;
    }

    if (motor_block == 1)
    {
        if (deltaAZ < 0)
        {

            TA0CCR2 = D;
            TA0CCR1 = 0;
        }
        else if (deltaAZ > 0)
        {
            TA0CCR2 = 0;
            TA0CCR1 = D;
        }
        else
        {
            TA0CCR2 = 0;
            TA0CCR1 = 0;
        }
    }
    else if (motor_block == 2)
    {

        TA1CCR1 = D_aux;
    }

}

/*==============================================================================
 * Description :stops azimuth motor (motor 1)
 * Parameter(s):
 * Return      :
 * ------------------------------------------------------------------------------ */
void MotorAZstop(char motor_block)
{
    if (motor_block == 1)
    {
        TA0CCR2 = 0;
        TA0CCR1 = 0;
    }
    else if (motor_block == 2)
    {
        TA1CCR1 = 0;

    }
}
    /*==============================================================================
     * Description : Displacement of elevation motors (motors 2 and 4)
     *              //                MSP430F66xx
     *
     *               -----------------
     *        /|\|             P1.4|--|
     *         | |                 | MOT2, EL
     *         --|RST          P1.5|--|
     *           |                 |
     *           |             P1.2|<-- HallSens2
     *           |                 |
     *           |             P3.5|--|
     *           |                 | MOT4, EL
     *           |             P3.6|--|
     *           |                 |
     *           |             P3.7|<-- HallSens4
     *
     * Parameter(s): double deltaEL in mm
     * Return      :
     * ------------------------------------------------------------------------------ */
    void MotorELmove(float deltaEL, char motor_block)
    {

        int D;
        int D_aux;
        int absDistEL = abs(DistEL);

        if (initial_counterEL < START_COUNTER)
        {
            D = LOW_SPEED;
            D_aux = LOW_SPEED_3;
            initial_counterEL += 0.1;
        }

        else if (absDistEL >= 25)
        {
            D = HIGH_SPEED;
            D_aux = HIGH_SPEED_3;

        }
        else if (absDistEL >= 8)
        {
            D = MEDIUM_SPEED;
            D_aux = MEDIUM_SPEED_3;

        }
        else
        {
            D = STOP_SPEED;
            D_aux = STOP_SPEED_3;

        }

        if (motor_block == 1)
        {
            if (deltaEL < 0)
            {

                TA0CCR4 = D;
                TA0CCR3 = 0;
            }
            else if (deltaEL > 0)
            {
                TA0CCR4 = 0;
                TA0CCR3 = D;
            }
            else
            {
                TA0CCR4 = 0;
                TA0CCR3 = 0;
            }
        }
        else if (motor_block == 2)
        {

            TA2CCR1 = D_aux;
        }
    }

    /*==============================================================================
     * Description :stops elevation motor (motor 2)
     * Parameter(s):
     * Return      :
     * ------------------------------------------------------------------------------ */
    void MotorELstop(char motor_block)
    {
        if (motor_block == 1)
        {
            TA0CCR4 = 0;
            TA0CCR3 = 0;
        }
        else if (motor_block == 2)
        {
            TA2CCR1 = 0;
        }

    }

    /*==============================================================================
     * Description : PWM configuration and initialization
     * Parameter(s):
     * Return      :
     * ------------------------------------------------------------------------------ */

    void initPWM()
    {

        P1DIR |= BIT6 + BIT7; //Motor 1 pins has outputs
        P1DIR |= BIT4 + BIT5; //Motor 2 pins has outputs
        P1SEL |= BIT4 + BIT5 + BIT6 + BIT7;

        GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN1); //3.1 Motor 3 IN 2
        GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN2); //3.2 Motor 3 IN 1

        GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN5); //3.5 Motor 4 IN 2
        GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN6); //3.6 Motor 4 IN 1

//SMCLK = 20MHz
//PWM freq = 40KHz -> PWM Period = 25us -> int = 25us*20MHz = 500
        //Setup Timer TA0
        TA0CCR0 = PWM_PERIOD;              // PWM Period -> 25us
        TA0CCTL1 = OUTMOD_7;                   // CCR1 reset/set
        TA0CCTL2 = OUTMOD_7;                  // CCR2  reset/set
        TA0CCTL3 = OUTMOD_7;                   // CCR3 reset/set
        TA0CCTL4 = OUTMOD_7;                  // CCR4  reset/set
        TA0CTL = TASSEL_2 + MC_1 + TACLR; // SMCLK, up mode, clear TAR

        //Setup Timer TA1
        TA1CCR0 = PWM_PERIOD_2;
        TA1CCTL0 = OUTMOD_0;
        TA1CCTL1 = OUTMOD_0;
        TA1CCTL0 |= CCIE;
        TA1CCTL1 |= CCIE;
        TA1CTL = TASSEL_2 + MC_1 + TACLR; // SMCLK, up mode, clear TAR

        //Setup Timer TA2
        TA2CCR0 = PWM_PERIOD_3;
        TA2CCTL0 = OUTMOD_0;
        TA2CCTL1 = OUTMOD_0;
        TA2CCTL0 |= CCIE;
        TA2CCTL1 |= CCIE;
        TA2CTL = TASSEL_2 + MC_1 + TACLR; // SMCLK, up mode, clear TAR
    }

    /*==============================================================================
     * Description : Comparator_B configuration and initialization
     * Parameter(s):
     * Return      :
     * ------------------------------------------------------------------------------ */

    void initComparator()
    {

        param.positiveTerminalInput = COMP_B_INPUT2; //Enable V+, input channel CB2 (default option: motor 1 current is measured)
        param.negativeTerminalInput = COMP_B_VREF; // VREF is applied to -terminal
        param.powerModeSelect = COMP_B_POWERMODE_ULTRALOWPOWER;  // normal mode
        param.outputFilterEnableAndDelayLevel = COMP_B_FILTEROUTPUT_DLYLVL1;
        param.invertedOutputPolarity = COMP_B_NORMALOUTPUTPOLARITY;
        Comp_B_init(COMP_B_BASE, &param);

        //Configuration for the low threshold (edge detection)
        //Shared reference (1.5V)* 2/32 = 0.09375 V
        refVoltageParam_Low.supplyVoltageReferenceBase = COMP_B_VREFBASE1_5V;
        refVoltageParam_Low.lowerLimitSupplyVoltageFractionOf32 = 0;/////////////
        refVoltageParam_Low.upperLimitSupplyVoltageFractionOf32 = 0;
        refVoltageParam_Low.referenceAccuracy = COMP_B_ACCURACY_STATIC;
        //----------------------------------------------------

        //Configuration for the high threshold (possible collision)
        //Shared reference (2.5V)* 30/32 = 2,34375 V
        refVoltageParam_High.supplyVoltageReferenceBase = COMP_B_VREFBASE_VCC;
        refVoltageParam_High.lowerLimitSupplyVoltageFractionOf32 = 32; //22 is the minimum coefficient to avoid normal movement detection
        refVoltageParam_High.upperLimitSupplyVoltageFractionOf32 = 32; //22 is the minimum coefficient to avoid normal movement detection
        refVoltageParam_High.referenceAccuracy = COMP_B_ACCURACY_STATIC;
        //----------------------------------------------------

        Comp_B_configureReferenceVoltage(COMP_B_BASE, &refVoltageParam_Low);
        __delay_cycles(1500);

        CBCTL1 |= CBON;
    }
