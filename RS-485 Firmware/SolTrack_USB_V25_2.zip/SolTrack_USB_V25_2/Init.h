/*
 * InitClocks.h
 *
 *  Created on: 28 June 2022
 *      Author: jonat
 *
 *  Last modification on: 29 September 2023.
 *  Author: Yubal Barrios
 */


#ifndef INIT_H_
#define INIT_H_

#include "gpio.h"

//Type pour la machine d'�tat
typedef enum{RESET, SETUP, STATUS, CALIBRATION, MANUAL_BOTH}MODE;
typedef enum{LAT, LONG, YEAR, MONTH, DAY, HOUR, MINUTE, SECOND, DEFAULT}DATA_SETUP;
//Variables globales pour la mesure du capteur Hall
extern char HallSens1, HallSens2;
extern float CurrentDistAZ, CurrentDistEL;
extern int isSleep;
void initPorts();
MODE ChooseMenu(char sel, int * setup, int * manual_both, int * tracking, int * calibration);
double strtod(const char *str, char **endptr);
int uint2bcd(unsigned int ival);

#endif /* INIT_H_ */
