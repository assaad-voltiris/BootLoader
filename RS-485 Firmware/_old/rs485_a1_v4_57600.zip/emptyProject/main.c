/* to create an empty project with driverlib do:
 *  File-> Import...
 *  Select:
 *    Code Composer Studio -> CCS Projects (Next)
 *  Go to the empty project in driverlib (in may case:)
 *    C:\ti\msp\MSP430Ware_3_80_14_01\driverlib\examples\MSP430F5xx_6xx\00_emptyProject\CCS
 *  It will show the Discovered projects:
 *    emptyProject[emptyProject.projectspec]
 *  Select it (if not selected) and click on Finish
 *  if it cannot be selected, it may be because you already have a project named emptyProject.
 *  In that case, rename that project to be able to import this one
 *
 *  Once you have imported the project, rename it
 *
 * Using the UART to communicate to the Arduino MKR-485 module
 *
 * UART RS-485 related pins in MSP-EXP430F5529L
 *  P8.2/UCA1TXD/UCA1SIMO/S13 -> Tx out
 *  P8.3/UCA1RXD/UCA1SOMI/S12 <- Rx in
 *
 * Also, the RS-485 Arduino MKR shield has 2 enable signals
 // P2.7 Transmitter output Enable. High to Enable
 *
 * - LED1 (P1.0)
 * - LED2 (P4.7)
 * - S1 (P2.1) -> Pushed to GND
 * - S2 (P1.1) -> Pushed to GND
 *
 */

//https://github.com/sshahryiar/MSP430F5529LP-Tutorial/blob/main/Code%20Examples/USCI-UART/main.c
// https://e2e.ti.com/support/microcontrollers/msp-low-power-microcontrollers-group/msp430/f/msp-low-power-microcontroller-forum/526106/uctxifg-how-does-it-work
#include <msp430.h>
#include "driverlib.h"

// delay.h
#define XT1_FREQ          32768
#define F_ACLK            32768
#define XT2_FREQ          8000000
#define MCLK_FREQ         20000000
#define F_SMCLK           20000000

#define F_MCLK              10000000
#define RTC_CYCLIC          (F_MAIN_LOOP / 4)   ///< Fetch time at 2 [Hz]
#define BAUD_RATE           115200

#define XT1_KHZ           (XT1_FREQ / 1000)
#define XT2_KHZ           (XT2_FREQ / 1000)
#define MCLK_KHZ          (MCLK_FREQ / 1000)

#define scale_factor       4

#define MCLK_FLLREF_RATIO (MCLK_KHZ / (XT2_KHZ / scale_factor))

#define CPU_F             ((double)F_MCLK)

#define delay_us(delay)   __delay_cycles((long)(CPU_F*(((double)delay)/1000000.0)))
#define delay_ms(delay)   __delay_cycles((long)(CPU_F*(((double)delay)/1000.0)))
// end delay.h

//char Data = 170; // 10101 0101 to have many transitions
char Data = 'U'; // 01010101
void GPIO_init(void);

void clock_init(void);
void USCI_UART_init(void);

void uartTransmit(void);
void uartReceive(void);

void main(void)
{
    WDT_A_hold(WDT_A_BASE);
    clock_init();
    USCI_UART_init();
    GPIO_init();
    P8OUT |= BIT7; // 1: disable transmiter


    while (1)
    {
        GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN2); // LED1 (P1.0): P1OUT ^= BIT0
        //GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN3); // LED1 (P1.0): P1OUT ^= BIT0


        //P8OUT &=  ~BIT7; // 0: enable transmiter
        //P2OUT &= ~BIT6; // 0: enable receiver
        uartTransmit();
        uartReceive();
        //delay_ms(5000);

        /*while (!(UCA1IFG & UCRXIFG)); // USCI_A1 RX buffer ready?
         Data = UCA1RXBUF; // Read the UART*/

        //while (!(UCA1IFG & UCTXIFG));  // stay while UCTXIFG=0,  USCI_A1 TX buffer ready?
        //UCA1TXBUF = UCA1RXBUF;                  // TX -> RXed character
        // Read UCAxIFG Register
        // UCTXIFG: Transmit interrupt flag. UCTXIFG is set when UCAxTXBUF empty.
        //   0: No interrupt pending
        //   1: Interrupt pending
        // UCRXIFG: Receive interrupt flag. UCRXIFG is set when UCAxRXBUF has received a complete character
        //   0: No interrupt pending
        //   1: Interrupt pending
        // Gets the current UART interrupt status.
        // This returns the interrupt status for the UART module based on which flag is passed.
        // Mask value is the logical OR of any of the following:
        // - USCI_A_UART_RECEIVE_INTERRUPT_FLAG - Receive interrupt flag
        // - USCI_A_UART_TRANSMIT_INTERRUPT_FLAG - Transmit interrupt flag
        // Wait until the data is transmitted: The UCTXIFG interrupt flag is set by the transmitter
        // to indicate that UCAxTXBUF is ready to accept another character.
        //while(USCI_A_UART_getInterruptStatus(USCI_A1_BASE,
        //                                     USCI_A_UART_TRANSMIT_INTERRUPT_FLAG) == 0);
    }
}

void uartTransmit()
{
    // Before RS-485 sending, since it is half-duplex:
    //  - disable (1) the receiver   P1.6 <-1
    //  - enable  (1) the transmiter P2.7 <-1
    //P2OUT |=  BIT6; // 1: disable receiver
    //GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN3); // LED1 (P1.0): P1OUT ^= BIT0
    P8OUT &= ~BIT7; // 0: enable transmiter
    //P8OUT |= BIT7; // 1: disable transmiter
    // write Data to UCAxTXBUF 8-bit Register
    // The transmit data buffer is user accessible and holds the data waiting to be
    // moved into the transmit shift register and transmitted on UCAxTXD. Writing to
    // the transmit data buffer clears UCTXIFG. The MSB of UCAxTXBUF is not used
    // for 7-bit data and is reset.
    // USCI_A_UART_transmitData(USCI_A1_BASE, Data);
    // check UCAxIFG register, its bit UCTXIFG (Transmit interrupt flag).
    //   UCTXIFG is set when UCAxTXBUF empty.
    //   0: No interrupt pending
    //   1: it has been sent
    while (!(UCA1IFG & UCTXIFG))
        ; // USCI_A1 TX buffer ready? stay while UCTXIFG=0
    USCI_A_UART_transmitData(USCI_A1_BASE, Data);
    while (UCA1STAT & UCBUSY)

        ; // USCI inactive?
    P8OUT |= BIT7; // 1: disable transmiter
    //while (!(UCA1IFG & UCRXIFG)); // USCI_A1 RX buffer ready?, to empty the transmission, which has been received
    //UCA1IFG &= ~UCRXIFG; // Same as before, it is redundant
}

void uartReceive()
{
    GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN3); // LED1 (P1.0): P1OUT ^= BIT0
    while (!(UCA1IFG & UCRXIFG)); // USCI_A1 RX buffer ready?
    Data = UCA1RXBUF;
    GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN3); // LED1 (P1.0): P1OUT ^= BIT0


}

void InitOscillator()
{
    while (BAKCTL & LOCKBAK)                    // Unlock XT1 pins for operation
        BAKCTL &= ~(LOCKBAK);

    UCSCTL6 &= ~(XT1OFF);                     // XT1 On
    UCSCTL6 |= XCAP_1;                        // Internal load cap

    P7SEL |= BIT2 + BIT3;                       // Port select XT2
    // FMS: I think this is not doing what is intended:
    // we are writing bits 15 14, whose reset value is 11
    // XT2DRIVE_0 is 0x0000 ->  ~XT2DRIVE_0 is 0xFFFF
    // Thus the AND leaves everything as it was
    // Since the reset value is 11 -> is leaving this value XT2DRIVE_3
    // XT2DRIVE_3 is 0xC000 -> bits 15 and 14 to 1, and we want to check these bits
    // So we set these bits to zero by
    // UCSCTL6 &= ~XT2DRIVE_3; // 1100 0000 0000 0000 -> & 0011 1111 1111 1111
    // and write the value we want (in this case is 00, we could leave them)
    // UCSCTL6 |= XT2DRIVE_0; //  | 0000 0000 0000 0000 -> the same
    UCSCTL6 &= ~XT2DRIVE_0;  // XT2 oscillator operating range is 4 MHz to 8 MHz

    UCSCTL6 &= ~XT2OFF;                       // Set XT2 On
    // Loop until XT1,XT2 & DCO stabilizes - In this case loop until XT1 and DCo settle
    do
    {
        UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
        // Clear XT2,XT1,DCO fault flags
        SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    }
    while (SFRIFG1 & OFIFG);                   // Test oscillator fault flag

    UCSCTL3 |= SELREF__XT2CLK | FLLREFDIV__2; // Set DCO FLL reference /2 = XT2/2 (4MHz)
    UCSCTL4 = SELA__XT1CLK | SELM__DCOCLK | SELS__DCOCLK; // Set ACLK = XT1(32kHz), SMCLK = DCO, MCLK = DCO
    UCSCTL5 |= DIVM__2 | DIVS__1 | DIVA__1; // MCLK = fSELM/2 = 10MHz  SMCLK = fSELS/1 = 20MHz
    __bis_SR_register(SCG0);                  // Disable the FLL control loop

    //UCSCTL0 = 0x0F80;                       // Select DCO range 2.5-54.1MHz operation
    UCSCTL1 = DCORSEL_5; // DCOx = auto MODx = auto, DCORSELx = 5 see datasheet page 31

    UCSCTL2 = FLLD__1 + FLLN2;              // Set Multiplier for 40MHz
                                            // D *(N + 1) * FLLRef = Fdco
                                            // 1 * (4 + 1) * 4MHz = 20MHz
                                            // FLL Div = fDCOCLK/1
    __bic_SR_register(SCG0);                  // Enable the FLL control loop

    // Worst-case settling time for the DCO when the DCO range bits have been
    // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 6xx
    // UG for optimization.
    // 32 x 32 x 10 MHz / 8MHz = 1280 = MCLK cycles for DCO to settle
    __delay_cycles(1280);

    // Loop until XT1,XT2 & DCO fault flag is cleared
    do
    {
        UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
        // Clear XT2,XT1,DCO fault flags
        SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    }
    while (UCSCTL7 & OFIFG);                   // Test oscillator fault flag

}

void clock_init(void)
{
    PMM_setVCore(PMM_CORE_LEVEL_3);

    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P5,
                                               (GPIO_PIN4 | GPIO_PIN2));

    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P5,
                                                (GPIO_PIN5 | GPIO_PIN3));

    UCS_setExternalClockSource(XT1_FREQ,
    XT2_FREQ);

    InitOscillator();
    //UCS_turnOnXT2(UCS_XT2_DRIVE_24MHZ_32MHZ);

    // capacitor Ci=9pF.  Ce ~ (Ci + 2 pF) / 2 = 11/2=5.5
    //  Values for UCS_XCAP are 0:2 pF,1:6 pF,2:9 pF, 3:12 pF
    // Thus: UCS_XCAP_1
    // UCSCTL6 &= ~(XT1OFF);                     // XT1 On
    // UCSCTL6 |= XCAP_1;                        // Internal load cap
    //UCS_turnOnLFXT1(UCS_XT1_DRIVE_3,
    //                UCS_XCAP_1);

    //UCS_initClockSignal(UCS_FLLREF,
    //                    UCS_XT2CLK_SELECT,
    //                    UCS_CLOCK_DIVIDER_4);

    //UCS_initFLLSettle(MCLK_KHZ,
    //                  MCLK_FLLREF_RATIO);

    //UCS_initClockSignal(UCS_SMCLK,
    //                    UCS_XT2CLK_SELECT,
    //                    UCS_CLOCK_DIVIDER_4);

    //UCS_initClockSignal(UCS_ACLK,
    //                    UCS_XT1CLK_SELECT,
    //                    UCS_CLOCK_DIVIDER_1);
}

void GPIO_init(void)
{
    GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN2); //P1.0 LED1
    //GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN2);

    GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN3); //P1.0 LED1
    //GPIO_setOutputHighOnPin(GPIO_PORT_P5, GPIO_PIN3);

    //GPIO_setDriveStrength(GPIO_PORT_P1,GPIO_PIN0,
    //                      GPIO_FULL_OUTPUT_DRIVE_STRENGTH);

    //GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN4); //P4.7 LED2

    //GPIO_setDriveStrength(GPIO_PORT_P4, GPIO_PIN7,
    //                      GPIO_FULL_OUTPUT_DRIVE_STRENGTH);

    // P8.3/UCA1RXD/UCA1SOMI/S12I
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P8, GPIO_PIN3); // UCA1 RX

    // P8.2/UCA1TXD/UCA1SIMO/S13
    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P8, GPIO_PIN2); // UCA1 TX
    P8REN &=  BIT2; // 1: to not have resistor at input (either pull up/down)


    // P1.6 Receiver output Enable. Low to Enable
    //GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN6);
    //GPIO_setOutputLowOnPin(GPIO_PORT_P2,GPIO_PIN6);

    // P2.7 Transmitter output Enable. Low to Enable
    GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN7);
    GPIO_setOutputHighOnPin(GPIO_PORT_P8, GPIO_PIN7); // Disabled

}

// To get the recommended parameters for MSP430 USCI/EUSCI UART Baud Rate Calculation
// https://software-dl.ti.com/msp430/msp430_public_sw/mcu/msp430/MSP430BaudRateConverter/index.html
// or from SLAU208q MSP430f5xx or MSP430f6xx
// 36.3.13. Table 36-4  Typical Baud Rates and Errors of MSP430x5xx and MSP430x6xx Family Users Guide.
// Using ACLK 32kHz to generate a baudrate 9600 bps, we get:
// clockPrescalar = 3
// firstModReg    = 0  // UCBRFx bits of UCAxMCTLW
// secondModReg   = 3  // UCBRSx bits of UCAxMCTLW
// overSampling   = 0  // UCOS16 bit  of UCAxMCTLW
// https://software-dl.ti.com/msp430/msp430_public_sw/mcu/msp430/MSP430_Driver_Library/latest/exports/driverlib/msp430_driverlib_2_91_13_01/doc/MSP430F5xx_6xx/html/struct_u_s_c_i___a___u_a_r_t__init_param.html
void USCI_UART_init(void)
{
    // structure for initializing the UART. Initialize to zero, and then include values
    USCI_A_UART_initParam UART_Param = { 0 };

    // --- UCAxCTL1 Register -------------------
    // use ACLK which is 32 768 Hz
    // UCSSELx: 01b : ACLK. 1xb: SMCLK
    //UART_Param.selectClockSource = USCI_A_UART_CLOCKSOURCE_ACLK;
    // use SMCLK which is 20 MHz
    UART_Param.selectClockSource = USCI_A_UART_CLOCKSOURCE_SMCLK;

    // --- UCBRx Register --------------------- Table 36.4 36.5
    // UCAxBR0 Register : Low byte
    // UCAxBR1 Register : High byte
    // UCBRx : Preescaler: (UCAxBR1 UCAxBR0) x 256
    //UART_Param.clockPrescalar = 6; // for AClk 32768 Hz 4800 baud
    UART_Param.clockPrescalar = 21; //UCBRx: for sMClk 20 MHz  UCOS16=1 57600 baud
    //UART_Param.clockPrescalar = 130; //UCBRx: for sMClk 20 MHz  UCOS16=1 9600 baud


    // --- UCAxMCTLW Register ------------------
    // First modulation stage select. These bits determine the modulation pattern for
    // BITCLK16 when UCOS16 = 1. Ignored with UCOS16 = 0.
    //UART_Param.firstModReg = 0;  // UCBRFx bits of UCAxMCTLW AClk 32768 Hz
    UART_Param.firstModReg = 11;  // UCBRFx bits of UCAxMCTLW sMClk 20 MHz  UCOS16=1  57600 baud
    //UART_Param.firstModReg = 3; // UCBRFx bits of UCAxMCTLW sMClk 20 MHz  UCOS16=1  9600 baud
    // Second modulation stage select. These bits hold a free modulation pattern for BITCLK
    //UART_Param.secondModReg = 7; // UCBRSx bits of UCAxMCTLW AClk 32768 Hz
    UART_Param.secondModReg = 0; // UCBRSx bits of UCAxMCTLW sMClk 20 MHz UCOS16=1  57600 baud
    //UART_Param.secondModReg = 0; // UCBRSx bits of UCAxMCTLW sMClk 20 MHz UCOS16=1  9600 baud
    UART_Param.overSampling = USCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION; //oversampling. UCOS16=1 sMClk 20 MHz  57600 baud
    //UART_Param.overSampling = USCI_A_UART_LOW_FREQUENCY_BAUDRATE_GENERATION; // no oversampling. UCOS16=0 AClk 32768 Hz 4800 baud


    // --- UCAxCTL0 Register -----------------------
    // UCPEN: 0 parity disabled, 1: Parity enabled
    // UCPAR: if parity enabled: 0: odd parity; 1b: even parity
    UART_Param.parity = USCI_A_UART_NO_PARITY;
    // UCMSB: 0: LSB first     ; 1: MSB
    UART_Param.msborLsbFirst = USCI_A_UART_LSB_FIRST;
    // UC7BIT: 0: 8-bit data   ; 1: 7-bit data
    // UCSPB:  0: One stop bit ; 1: Two stop bits
    UART_Param.numberofStopBits = USCI_A_UART_ONE_STOP_BIT;
    // UCSYNC: 0: synchronous mode ; 1: asynchronous mode
    // UCMODEx: USCI mode, (when UCSYNC: 0): 00b: UART mode
    UART_Param.uartMode = USCI_A_UART_MODE;

    // Now we write all the data we have saved in the struct:
    // USCI A1:  P8.2/UCA1TXD/UCA1SIMO/S13 P8.3/UCA1RXD/UCA1SOMI/S12
    USCI_A_UART_init(USCI_A1_BASE, &UART_Param);
    // This function includes disabling the USCI Module:
    // UCA0CTL1 |= UCSWRST;

    // Re-enables UART module from dormant mode.
    // UCAxCTL1 Reg:
    //  UCDORM:
    //      0: Not dormant: All received characters set UCRXIFG
    //      1: Dormant. Only characters that are preceded by an idle-line or with address
    //         bit set UCRXIFG. In UART mode with automatic baud-rate detection, only the
    //         combination of a break and synch field sets UCRXIFG.
    USCI_A_UART_resetDormant(USCI_A1_BASE);

    // Enables the UART block
    // UCAxCTL1 Reg:
    //   UCSWRST: Software reset enable
    //     0: Disabled. USCI reset released for operation.
    //     1: Enabled. USCI logic held in reset state.
    USCI_A_UART_enable(USCI_A1_BASE); //Reset the UCSWRST bit to enable the USCI Module
    // UCA0CTL1 &= ~UCSWRST; // equivalent



    // --- UCAxCTL1 and UCAxIE Registers -------------------
    // Enables individual UART interrupt sources.
    // Enables the indicated UART interrupt sources. The interrupt flag is first and then the corresponding interrupt is enabled.
    // Only the sources that are enabled can be reflected to the processor interrupt; disabled sources have no effect on the processor.
    // Does not clear interrupt flags.
    // mask of the interrupt sources to be enabled. Mask value is the logical OR of any of the following:
    // USCI_A_UART_RECEIVE_INTERRUPT - Receive interrupt :   UCAxIE -> UCRXIE: 0 disabled ; 1: enabled
    // USCI_A_UART_TRANSMIT_INTERRUPT - Transmit interrupt:  UCAxIE -> UCTXIE: 0 disabled ; 1: enabled
    // USCI_A_UART_RECEIVE_ERRONEOUSCHAR_INTERRUPT - Receive erroneous-character interrupt enable: UCAxCTL1 -> UCRXEIE
    //   0: Erroneous characters rejected and UCRXIFG is not set.
    //   1: Erroneous characters received set UCRXIFG.
    // USCI_A_UART_BREAKCHAR_INTERRUPT - Receive break character interrupt enable: UCAxCTL1 -> UCBRKIE
    //   0: Received break characters do not set UCRXIFG.
    //   1: Received break characters set UCRXIFG.

    //USCI_A_UART_enableInterrupt(USCI_A1_BASE, USCI_A_UART_RECEIVE_INTERRUPT);
    // UCA1IE |= UCRXIE;  // equivalent

    //__enable_interrupt(); //__bis_SR_register(GIE);       //interrupts enabled

}

